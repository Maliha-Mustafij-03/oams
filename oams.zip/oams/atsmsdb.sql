-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2024 at 03:44 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atsmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblabroademp`
--

CREATE TABLE `tblabroademp` (
  `ID` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `EducationalQ` varchar(200) DEFAULT NULL,
  `Organization` varchar(50) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `empid` varchar(25) DEFAULT NULL,
  `emobilenumber` varchar(250) DEFAULT NULL,
  `Designation` varchar(250) DEFAULT NULL,
  `EntryDate` timestamp NULL DEFAULT current_timestamp(),
  `postingplace` varchar(100) DEFAULT NULL,
  `Typeofteam` varchar(100) DEFAULT NULL,
  `Remark` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblabroademp`
--

INSERT INTO `tblabroademp` (`ID`, `image`, `EducationalQ`, `Organization`, `Name`, `empid`, `emobilenumber`, `Designation`, `EntryDate`, `postingplace`, `Typeofteam`, `Remark`) VALUES
(61, '', 'MSC', 'Bangladesh Election Commission', 'Mr.Ashoke Kumar Debnath', '', '0101010101', 'Additional Secretary', '2024-03-25 06:31:31', 'Headquarter', 'Admin Team', 'good'),
(62, '', 'MSC', 'IDEA Project (Phase-2)', 'Md. Nuruzzaman Khan', '', '0101010101', 'Additional Project Director', '2024-03-25 06:32:58', 'Headquarter', '', 'APD Idea Project(Phase-2)'),
(63, '', 'MSC', 'Bangladesh Election Commission', 'Md. Humayun Kabir', '', '0101010101', 'Regional Election officer', '2024-03-25 06:35:16', 'Headquarter', 'Admin Team', 'good'),
(64, '', 'PHD', 'Bangladesh Election Commission', 'M. Mazharul Islam', '', '0101010101', 'Deputy Secretary', '2024-03-25 06:37:48', 'Headquarter', '', 'good'),
(65, '', 'B.S.C Engineer', 'NID Wing', 'mohammed shohag', '', '010101', 'Maintennance Engineer', '2024-03-25 07:04:14', 'Headquarter', 'Technical Team', 'good'),
(66, '', 'B.S.C Engineer', 'NID Wing', 'A.S.M Iqbal Hasan', '', '010101010', 'Deputy Director', '2024-03-25 07:05:36', 'Headquarter', 'Technical Team', 'good'),
(68, '', 'MSC', 'IDEA Project (Phase-2)', 'Md.Akhtaruzzaman', 'id-5032', '01000101', 'Assistant Programmer', '2024-03-25 07:10:57', 'Headquarter', 'Technical Team', 'good'),
(69, '', 'MSC', 'IDEA Project (Phase-2)', 'Md.Kamrul Islam', 'id-5431', '010101010', 'Assistance Programmer', '2024-03-25 07:12:18', 'Headquarter', 'Technical Team', 'good'),
(70, '', 'BSC in CSE', 'IDEA Project (Phase-2)', 'Md.Shohel Sikder', 'id-5057', '010101010', 'Assistance Programmer', '2024-03-25 07:13:55', 'Headquarter', 'Technical Team', 'good'),
(71, '', 'Masters in Bangla', 'IDEA Project (Phase-2)', 'Tanjima Hossain', 'id-5166', '010101010', 'Assistant Programmer', '2024-03-25 07:16:48', 'Headquarter', 'Technical Team', 'good'),
(72, '', 'honours', 'NID Wing', 'Sazzadul Hasan', '', '101001010', 'Office assistance Cum-Computer Typist', '2024-03-25 07:19:38', 'Headquarter', 'Technical Team', 'good'),
(73, '', 'HSC', 'IDEA Project (Phase-2)', 'Md. Masudur rahman', 'id-081466', '0101010', 'Data Entry Operator', '2024-03-25 07:20:50', 'Headquarter', 'Technical Team', 'good'),
(74, '', 'Masters Finance', 'IDEA Project (Phase-2)', 'Md. Rokun Uddin Sikdr', 'id-7107', '010101010', 'Machine Operator', '2024-03-25 07:22:57', 'Headquarter', 'Technical Team', 'good'),
(75, '', 'Diploma-Computer', 'IDEA Project (Phase-2)', 'Zahidul Islam', 'id-051710', '010101010', 'Data Entry Operator', '2024-03-25 07:23:56', 'Headquarter', 'Technical Team', 'good'),
(78, '', 'B.S.C Engineer', 'IDEA Project (Phase-2)', 'Major Md.Mamunur Rashid', 'BA-8236', '01769198844', 'Deputy Project Director', '2024-03-25 07:49:53', 'Headquarter', '', 'good'),
(79, '', 'B.S.C Engineer', 'NID Wing', 'Md. Mokhlesur Rahman', '', '010101010', 'Deputy  Director', '2024-03-25 07:51:09', 'Headquarter', 'Technical Team', 'good'),
(80, '', 'MSC', 'NID Wing', 'Md. Takdir Ahmed', '', '010101010', 'Deputy Director', '2024-03-25 07:53:50', 'Headquarter', 'Technical Team', 'good'),
(81, '', 'MSC', 'Bangladesh Election Commission', 'Mohammad Asad uzzaman', 'id-45', '0101010100', 'Assistant Programmer', '2024-03-25 07:55:35', 'Headquarter', 'Technical Team', 'good'),
(82, '', 'Masters Finance', 'IDEA Project (Phase-2)', 'Md. Sujon Hossain', 'id-5073', '01010101', 'Assistant Programmer', '2024-03-25 07:56:45', 'Headquarter', 'Technical Team', 'good'),
(83, '', 'B.S.C Engineer', 'IDEA Project (Phase-2)', 'Md.Imam Raihan', 'id-5239', '0101010101', 'Assistant Programmer', '2024-03-25 07:58:41', 'Headquarter', 'Technical Team', 'good'),
(84, '', 'Masters Economics', 'IDEA Project (Phase-2)', 'Mehedi Hasan', 'id-5118', '01010101010', 'Assistant Programmer', '2024-03-25 08:00:42', 'Headquarter', 'Technical Team', 'good'),
(85, '', 'BSC in CSE', 'IDEA Project (Phase-2)', 'Abir Hasan', 'id-8185', '0101010010', 'Senior Computer Operator', '2024-03-25 08:02:24', 'Headquarter', 'Technical Team', 'good'),
(86, '', 'Masters Accounting', 'IDEA Project (Phase-2)', 'Mohammad Jahid Akon', 'id-031566', '0101010101', 'Data Entry Operator', '2024-03-25 08:04:03', 'Headquarter', 'Technical Team', 'good'),
(87, '', 'Masters Political Science', 'IDEA Project (Phase-2)', 'Md. Rashel Paik', 'id-00916', '010101001', 'Data Entry Operator', '2024-03-25 08:05:11', 'Headquarter', 'Technical Team', 'good'),
(89, '', 'Masters Bangla', 'IDEA Project (Phase-2)', 'Imran Hossain', 'id-031645', '0101010100', 'Data Entry Operator', '2024-03-25 08:07:30', 'Headquarter', 'Technical Team', 'good'),
(90, '', 'MSC', 'NID Wing', 'A.K.M Humayun Kabir', '', '0101010100', 'Director general (Grade-1)', '2024-03-27 03:29:06', 'Headquarter', 'Admin Team', 'good'),
(91, '', 'MSC', 'NID Wing', 'Mohammad Ashraf hossain', '', '0101010100', 'System Manager', '2024-03-27 03:33:26', 'Headquarter', 'Admin Team', 'good'),
(93, '', 'MSC', 'NID Wing', 'Md.Rajib Ahsan', '', '0101010100', 'Senior Assistance chief(cc)', '2024-03-27 03:37:53', 'Headquarter', 'Admin Team', 'good'),
(94, '', 'BGBMS,afwc,psc,M phil', 'IDEA Project (Phase-2)', 'Brigidier General Abul hasnat Mohammad Sayem', '', '0101010100', 'Project Director', '2024-03-27 03:42:52', 'Headquarter', 'Admin Team', 'good'),
(95, '', 'MSC', 'NID Wing', 'Md. Abdul Momin Sarker', '', '0101010100', 'Director', '2024-03-27 03:44:08', 'Headquarter', 'Admin Team', 'good'),
(96, '', 'Masters', 'NID Wing', 'Mohammad Azizul Islam', '', '0101010100', 'Regional Election officer', '2024-03-27 03:45:13', 'Headquarter', 'Admin Team', 'good'),
(97, '', 'BSC in Civil', 'IDEA Project (Phase-2)', 'Major Shueb Al Hasan', '', '0101010100', 'Deputy Project Director', '2024-03-27 03:46:30', 'Headquarter', 'Admin Team', 'good'),
(98, '', 'MSC', 'IDEA Project (Phase-2)', 'Squadron leader Saad Waiez Tanveer', '', '0101010100', 'Director(IT)', '2024-03-27 03:57:40', 'Headquarter', 'Technical Team', 'good'),
(100, '', 'MSC', 'NID Wing', 'Md. Mizanur Rahman Khan', '', '0101010100', 'Upazila Election Officer', '2024-03-27 04:00:39', 'Headquarter', 'Technical Team', 'good'),
(101, '', 'MSC', 'NID Wing', 'Md.Kamrul Hasan', '', '0101010100', 'Upazila Election Officer', '2024-03-27 04:01:46', 'Headquarter', 'Technical Team', 'good'),
(102, '', 'MSC', 'NID Wing', 'Md.Salim UL Alam', '', '0101010100', 'Programmer', '2024-03-27 04:02:48', 'Headquarter', 'Technical Team', 'good'),
(103, '', 'MSC', 'IDEA Project (Phase-2)', 'Md. Shawkatn Akbar  Munshii', '', '0101010100', 'Netwark Consultant', '2024-03-27 04:04:30', 'Headquarter', 'Technical Team', 'good'),
(104, '', 'BSC', 'NID Wing', 'Aminul Islam', '', '0101010100', 'Assistant Programmer', '2024-03-27 04:05:34', 'Headquarter', 'Technical Team', 'good'),
(106, '', 'MSC', 'NID Wing', 'Md. Mahfuzur Rahman', '', '0101010010', 'Office Assistant cum computer opeartor', '2024-03-27 04:07:54', 'Headquarter', 'Technical Team', 'good'),
(107, '', 'honours', 'NID Wing', 'Md. Hakim uddin Prodhan', '', '0101010010', 'Office Assistant cum computer opeartor', '2024-03-27 04:09:15', 'Headquarter', 'Technical Team', 'good'),
(108, '', 'Masters Management', 'IDEA Project (Phase-2)', 'Md. Abu Naser Hamid', 'id-061200', '0101010010', 'Data Entry Operator', '2024-03-27 04:10:19', 'Headquarter', 'Technical Team', 'good'),
(109, '', 'Masters Accounting', 'IDEA Project (Phase-2)', 'Md. Moazzem Hossain', 'id-082138', '0101010010', 'Data Entry Operator', '2024-03-27 04:11:12', 'Headquarter', 'Technical Team', 'good'),
(112, '', 'MSC', 'Others', 'Dr. Shah Mohammad Tanvir Monsur', '', '0101010010', 'Director General, Consular and welfare wing', '2024-03-27 05:20:06', 'Headquarter', 'Admin Team', 'Ministry Of Foreign affairs'),
(114, '', 'MSC', 'Others', 'Md.Sarowar Alam', '', '0101010010', 'Senior Assistant Secretary', '2024-03-27 05:24:07', 'Headquarter', 'Inauguration Team', 'Ministry of expatriates welfare &Overseas Employment'),
(115, '', 'MSC', 'NID Wing', 'Muhammad Sarwar Hossain', '', '0101010010', 'Assistant Director', '2024-03-27 05:25:08', 'Headquarter', 'Admin Team', 'good'),
(116, '', 'MSC', 'NID Wing', ' Engineer Mohammad Ariful Islam', '', '0101010010', 'System Analyst', '2024-03-27 05:28:28', 'Headquarter', '', 'good'),
(117, '', 'MSC', 'NID Wing', 'Md. Rashid Miah', '', '0101010010', 'Deputy Director', '2024-03-27 05:29:41', 'Headquarter', 'Technical Team', 'good'),
(118, '', 'BSC in CSE', 'IDEA Project (Phase-2)', 'Papiya Hossain Lima', 'id-5138', '0101010010', 'Assistant Programmer', '2024-03-27 05:30:45', 'Headquarter', 'Technical Team', 'good'),
(119, '', 'Masters', 'IDEA Project (Phase-2)', 'Rezaul Karim', 'id-5031', '0101010010', 'Assistant Programmer', '2024-03-27 05:31:31', 'Headquarter', 'Technical Team', 'good'),
(120, '', 'BSC', 'NID Wing', 'Sapan Kumar Das', '', '0101010010', 'Account Assistant', '2024-03-27 05:33:10', 'Headquarter', 'Technical Team', 'good'),
(121, '', 'honours', 'NID Wing', 'S.M Mahobub Hassan', '', '0101010010', 'Office Assistant cum Computer Typist', '2024-03-27 05:34:31', 'Headquarter', 'Technical Team', 'good'),
(123, '', 'MSC', 'NID Wing', 'Md. Rafiqul Hoque', '', '0101010101', 'System Manager', '2024-03-27 05:37:03', 'Headquarter', 'Admin Team', 'good'),
(125, '', 'MSC', 'NID Wing', 'Mohammad Hasanuzzaman', '', '0101010101', 'Director and additional Director', '2024-03-27 05:40:02', 'Headquarter', 'Admin Team', 'good'),
(127, '', 'MSC', 'NID Wing', 'Mr.Md. Foridul Islam', '', '020202020', 'Regional Election Officer', '2024-03-28 03:51:16', 'Headquarter', 'Admin Team', 'good'),
(128, '', 'MSC', 'NID Wing', 'Mr.farazy Bengir Ahmed', '', '0989888787', 'Seniour District Election Officer', '2024-03-28 03:52:42', 'Headquarter', 'Admin Team', 'good'),
(129, '', 'MSC', 'IDEA Project (Phase-2)', 'Lieutetant Commander Ashraful Haque', '', '20200202', 'Zeehad,(X),BN,Officer-In-Charge', '2024-03-28 03:59:31', 'Headquarter', 'Technical Team', 'good'),
(130, '', 'MSC', 'NID Wing', 'Muhammad Tazul Islam', '', '030303030', 'Director', '2024-03-28 04:01:01', 'Headquarter', 'Technical Team', 'good'),
(132, '', 'Masters', 'IDEA Project (Phase-2)', 'Md Aulad Hossen', 'id-5074', '020202020', 'Assistant Programmer', '2024-03-28 04:05:55', 'Headquarter', 'Technical Team', 'good'),
(133, '', 'Masters', 'NID Wing', 'Md Gias uddin', '', '010101001', 'Warrant Officer', '2024-03-28 04:07:30', 'Headquarter', 'Technical Team', 'good'),
(137, '', 'Masters', 'IDEA Project (Phase-2)', 'Md.Ruhul Amin Mollik', '', '010101010', 'Project director', '2024-03-28 04:17:54', 'Headquarter', 'Admin Team', 'good'),
(140, '', 'BBA-finance', 'IDEA Project (phase_2)', 'Md Asfaqur Rahman', 'id-082336', '9977', 'Data Entry operator', '2024-03-31 03:39:21', 'Headquarter', 'Technical Team', 'good'),
(141, '', 'Masters', 'NID Wing', 'S.M.Shahadat Hossain', '', '010101010', 'District Election Officer', '2024-04-02 04:17:09', 'District', 'Admin Team', 'good'),
(142, '', 'Masters', 'NID Wing', 'Akhtaruzzaman', '', '0101010101', 'System analyst', '2024-04-02 04:28:40', 'Headquarter', 'Technical Team', 'good'),
(143, '', 'Masters', 'NID Wing', 'Farzana rahman', '', '0101010101', 'Assistance Director', '2024-04-02 04:29:51', 'Headquarter', 'Technical Team', 'good'),
(144, '', 'Masters', 'NID Wing', 'Arafat ara', '', '0101010101', 'Deputy Director', '2024-04-02 04:31:18', 'Headquarter', 'Technical Team', 'good'),
(145, '', 'Masters', 'NID Wing', 'Shifat Jahan', '', '0101010100', 'Programmer', '2024-04-02 04:32:25', 'Headquarter', 'Technical Team', 'good'),
(146, '', 'MSC', 'IDEA Project (Phase-2)', 'Md. Shahabuddin', '', '0101010100', 'Assistant Programmer', '2024-04-02 04:35:48', 'Headquarter', 'Technical Team', 'good'),
(147, '', 'MSC', 'IDEA Project (Phase-2)', 'Jahanara Akter', '', '0101010100', 'Assistant Programmer', '2024-04-02 04:36:50', 'Headquarter', 'Technical Team', 'good'),
(148, '', 'Master Accounting', 'IDEA Project (Phase-2)', 'Md.Saiful Islam', '', '0101010100', 'Assistant Programmer', '2024-04-02 04:38:04', 'Headquarter', 'Technical Team', 'good'),
(149, '', 'honours', 'NID Wing', 'Fatema Akter', '', '0101010100', 'Office Assistance Cum-Computer', '2024-04-02 04:40:58', 'Headquarter', 'Technical Team', 'good'),
(150, '', 'honours', 'IDEA Project (Phase-2)', 'Mominul Islam', '', '0101010100', 'Data Entry Operator', '2024-04-02 04:41:58', 'Headquarter', 'Technical Team', 'good'),
(151, '', 'honours', 'IDEA Project (Phase-2)', 'Mahbubur Rahman', '', '0101010100', 'Data Entry operator', '2024-04-02 04:43:01', 'Headquarter', 'Technical Team', 'good'),
(152, '', 'honours', 'IDEA Project (Phase-2)', 'Md.Tohidul Islam', '', '0101010100', 'Data Entry Operator', '2024-04-02 04:44:01', 'Headquarter', 'Technical Team', 'good'),
(155, '', '', 'Bangladesh Election Commission', 'Rasheda Sultana', '', '', 'Chief Election Commissioner ', '2024-04-03 05:57:27', 'Headquarter', 'Inauguration Team', 'good'),
(156, '', '', 'Bangladesh Election Commission', 'Mohammad Mahbubur Rahman Sarker', '', '', 'Joint Secretary', '2024-04-03 06:00:57', 'Headquarter', 'Inauguration Team', 'good'),
(157, '', '', 'Bangladesh Election Commission', 'Habiba Akhter', '', '', 'Personal Secretary', '2024-04-03 06:04:32', 'Headquarter', 'Inauguration Team', 'personal Secretary of CSE begum Rasheda Sultana'),
(158, '', '', 'Election Commission Secretariat', 'Honourable Brigidier General Mohammad Ahsan Habib', '', '', 'Election Commissioner', '2024-04-03 06:09:06', 'Headquarter', '', ''),
(159, '', '', 'Bangladesh Election Commission', 'Mohammad Moniruzzaman taluqdar', '', '', 'Joint Secretary ', '2024-04-03 06:11:35', 'Headquarter', 'Inauguration Team', ''),
(160, '', '', 'IDEA Project (phase_2)', 'Lieutenant Commander mohammad Khalid Hasan', '', '', 'Deputy Project Director', '2024-04-03 06:13:53', 'Headquarter', 'Inauguration Team', ''),
(161, '', 'BSc Engg,MSc,M. phil', 'bd', 'maliha', 'p1-034', '0189456788', 'ap', '2024-04-09 05:12:33', 'dhk', 'Others', 'oke'),
(162, '', 'BSc Engg,MBA,MSc,M. phil', 'bdd', 'johir imam', 'p1-0426', '', 'dd', '2024-04-09 05:23:09', 'dhaka', 'Others', ''),
(163, '', '', 'ministry of foreign affairs', 'foysal raihan', 'p1-034', '', 'ap', '2024-04-09 05:27:48', 'dhk', 'trippppp', ''),
(164, '', '', 'IDEA Project (phase_2)', 'mou', 'p1-034', '0986544', 'dd', '2024-04-15 06:06:52', 'dhk', '', ''),
(165, '', 'mba', 'dhaka bank', 'tazreen', 'p1-023', '0189456788', 'dd', '2024-04-16 04:45:08', 'dhaka', '', 'ok'),
(166, '', 'mba', 'dhaka bank', 'kunjo', 'p1-098', '0189456788', 'dd', '2024-04-16 05:02:59', 'dhaka', NULL, 'oke'),
(167, '', '', 'ICT Wing', 'mou', 'p1-034', '', 'ap', '2024-04-16 05:12:24', 'dhaka', '', ''),
(168, '', '', 'Bangladesh Election Commission ', 'Honble Brigidier General Mohammad ', 'p1-034', '0101010000', 'Project Director', '2024-04-21 03:30:13', 'dhaka', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(5) NOT NULL,
  `UserName` char(45) DEFAULT NULL,
  `MobileNumber` bigint(11) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp(),
  `Permissions` enum('admin','user') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`, `Permissions`) VALUES
(15, 'user', NULL, NULL, '$2y$10$mCwbfHOSb8Zt1DCKIV8/qOOFOdFXy7Zy4blJWtv6N0CxKWw85GV8i', '2024-03-31 15:45:29', 'user'),
(16, 'admin', NULL, NULL, '$2y$10$fYGUeJxHU2D2zLv.PCkZr.ayByUQvxxjrnSv8eSi0kXjYeIVy3h4G', '2024-03-31 15:46:34', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country_visits`
--

CREATE TABLE `tbl_country_visits` (
  `id` int(11) NOT NULL,
  `entry_id` int(11) NOT NULL,
  `visited_country` varchar(255) NOT NULL,
  `type_of_visit` varchar(255) NOT NULL,
  `go_no` varchar(255) NOT NULL,
  `total_date` int(11) NOT NULL,
  `visit_details` text NOT NULL,
  `time_duration1` date NOT NULL,
  `time_duration2` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_country_visits`
--

INSERT INTO `tbl_country_visits` (`id`, `entry_id`, `visited_country`, `type_of_visit`, `go_no`, `total_date`, `visit_details`, `time_duration1`, `time_duration2`) VALUES
(138, 80, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(158, 100, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(159, 101, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(160, 102, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(176, 117, 'kuwait', '', '', 0, '', '2024-03-20', '2024-04-04'),
(179, 120, 'kuwait', '', '', 0, '', '2024-03-20', '2024-04-04'),
(180, 121, 'kuwait', '', '', 0, '', '2024-03-20', '2024-04-04'),
(188, 127, 'Malaysia', '', '', 0, '', '2024-03-29', '2024-04-04'),
(191, 129, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(192, 130, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(197, 133, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(202, 137, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(226, 95, 'KSA', '', '', 0, '', '2023-10-22', '2023-10-28'),
(227, 95, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(228, 91, 'UK', '', '', 0, '', '2023-10-17', '2023-10-23'),
(229, 91, 'UAE', '', '', 0, '', '2023-05-25', '2023-05-30'),
(236, 118, 'Kuwait', '', '', 0, '', '2024-03-20', '2024-04-04'),
(237, 119, 'Kuwait', '', '', 0, '', '2024-03-20', '2024-04-04'),
(239, 69, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(242, 73, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(243, 74, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(245, 75, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(253, 82, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(255, 83, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(256, 84, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(257, 85, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(258, 86, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(259, 87, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(260, 89, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(263, 132, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(264, 140, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(265, 108, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(266, 109, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(267, 90, 'UAE', '', '', 0, '', '2023-10-17', '2023-10-23'),
(268, 90, 'UK', '', '', 0, '', '2023-05-25', '2023-05-30'),
(274, 115, 'UAE', '', '', 0, '', '2023-05-25', '2023-05-30'),
(275, 106, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(279, 103, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(280, 104, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(281, 107, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(282, 94, 'KSA', '', '', 0, '', '2023-10-22', '2023-10-28'),
(283, 94, 'Qatar', '', '', 0, '', '2023-05-25', '2023-05-30'),
(284, 94, 'UAE', '', '', 0, '', '2024-03-20', '2024-04-04'),
(285, 79, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(286, 96, 'KSA', '', '', 0, '', '2023-10-22', '2023-10-28'),
(289, 65, 'UK', '', '', 0, '', '2923-10-10', '2023-10-24'),
(290, 66, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(292, 70, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(293, 71, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(294, 72, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(298, 141, 'UK', '', '', 0, '', '2023-10-17', '2023-10-23'),
(299, 93, 'UK', '', '', 0, '', '2023-10-17', '2023-10-23'),
(307, 147, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(308, 148, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(309, 149, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(310, 150, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(311, 151, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(312, 152, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(313, 145, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(314, 144, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(316, 142, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(321, 123, 'Kuwait', '', '', 0, '', '2024-03-29', '2024-04-04'),
(322, 125, 'Kuwait', '', '', 0, '', '2024-03-29', '2024-04-04'),
(323, 128, 'Malaysia', '', '', 0, '', '2024-03-29', '2024-04-04'),
(324, 143, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(329, 146, 'Italy', '', '', 0, '', '2023-10-11', '2023-10-25'),
(330, 146, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(331, 98, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(332, 68, 'UK', '', '', 0, '', '2023-10-10', '2023-10-24'),
(334, 112, 'UAE', '', '', 0, '', '2023-05-25', '2023-05-30'),
(337, 61, 'Italy', '', '', 0, '', '2023-10-18', '2023-10-24'),
(338, 61, 'Malaysia', '', '', 0, '', '2024-03-29', '2024-04-04'),
(345, 81, 'KSA', '', '', 0, '', '2023-10-15', '2023-10-29'),
(346, 81, 'Qatar', '', '', 0, '', '2024-03-20', '2024-04-04'),
(347, 155, 'Italy', '', '', 0, '', '2024-02-23', '2024-02-27'),
(349, 157, 'Italy', '', '', 0, '', '2024-02-23', '2024-02-27'),
(351, 159, 'UAE', '', '', 0, '', '2023-05-31', '2023-06-12'),
(352, 160, 'UAE', '', '', 0, '', '2023-05-31', '2023-06-12'),
(353, 156, 'Italy', '', '', 0, '', '2024-02-23', '2024-02-27'),
(354, 114, 'UAE', '', '', 0, '', '2023-05-25', '2023-05-30'),
(355, 97, 'KSA', '', '', 0, '', '2023-10-22', '2023-10-28'),
(356, 63, 'Italy', '', '', 0, '', '2023-10-18', '2023-10-24'),
(357, 161, 'Thailand', '', '', 0, '', '2024-04-18', '2024-04-25'),
(358, 162, 'uganda', '', '', 0, '', '2024-04-25', '2024-04-30'),
(359, 163, 'uganda', '', '', 0, '', '2024-04-10', '2024-04-26'),
(363, 78, 'KSA', 'tech team', 'not published yet', 5, 'ok', '2023-10-15', '2023-10-29'),
(364, 78, 'Thailand', 'Inspection', 'not published yet', 2, 'for factory visit', '2024-04-27', '2024-04-29'),
(368, 166, 'Canada', 'Inaugration Team', 'not published yet', 4, 'remarks', '2024-04-17', '2024-04-30'),
(369, 165, 'Bangladesh', 'trip', 'not published yet', 4, 'remarks', '2024-04-30', '2024-04-25'),
(370, 165, 'grrece', 'trip', 'not published yet', 4, 'remarks', '2024-04-23', '2024-04-30'),
(375, 167, 'Canada', 'Technical Team', 'not published yet', 3, 'r', '2024-04-30', '2024-04-30'),
(376, 167, 'uganda', 'trip', 'not published yet', 3, 'r', '2024-04-30', '2024-04-24'),
(378, 164, 'australia', '', '', 0, '', '2024-04-16', '2024-04-17'),
(383, 158, 'UAE', '', '', 0, '', '2023-05-31', '2023-06-12'),
(384, 168, 'UAE', 'Admin Team', '', 0, '', '2024-04-30', '2024-04-30'),
(385, 64, 'Italy', 'PSI', '', 0, '', '2023-10-18', '2023-10-24'),
(386, 116, 'Kuwait', 'PSI', '', 0, '', '2024-03-20', '2024-04-04'),
(387, 116, 'UAE', '', '', 0, '', '2023-05-18', '2023-05-31'),
(390, 62, 'Italy', '', '', 0, '', '2023-10-18', '2023-10-24'),
(391, 62, 'Kuwait', '', '', 0, '', '2024-03-29', '2024-04-04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page_visits`
--

CREATE TABLE `tbl_page_visits` (
  `id` int(11) NOT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_page_visits`
--

INSERT INTO `tbl_page_visits` (`id`, `visit_date`, `visit_count`) VALUES
(1, '2024-03-21', 119),
(2, '2024-03-23', 8),
(3, '2024-03-24', 2),
(4, '2024-03-25', 14),
(5, '2024-03-27', 1),
(6, '2024-03-28', 5),
(7, '2024-03-30', 8),
(8, '2024-03-30', 8),
(9, '2024-03-31', 22),
(10, '2024-04-01', 4),
(11, '2024-04-02', 5),
(12, '2024-04-03', 13),
(13, '2024-04-08', 10),
(14, '2024-04-09', 8),
(15, '2024-04-15', 63),
(16, '2024-04-16', 31),
(17, '2024-04-18', 3),
(18, '2024-04-21', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblabroademp`
--
ALTER TABLE `tblabroademp`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_country_visits`
--
ALTER TABLE `tbl_country_visits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entry_id` (`entry_id`);

--
-- Indexes for table `tbl_page_visits`
--
ALTER TABLE `tbl_page_visits`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblabroademp`
--
ALTER TABLE `tblabroademp`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_country_visits`
--
ALTER TABLE `tbl_country_visits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=392;

--
-- AUTO_INCREMENT for table `tbl_page_visits`
--
ALTER TABLE `tbl_page_visits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_country_visits`
--
ALTER TABLE `tbl_country_visits`
  ADD CONSTRAINT `tbl_country_visits_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `tblabroademp` (`ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
