<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['login'])) {
    $adminuser = $_POST['username'];
    $password = $_POST['password'];
    
    // Check if the user exists in tbladmin with 'user' permission
    $query_user = mysqli_query($con, "SELECT ID, Password FROM tbladmin WHERE UserName='$adminuser' AND Permissions='user'");
    if (!$query_user) {
        die(mysqli_error($con)); // Check for query error
    }
    $row_user = mysqli_fetch_assoc($query_user);
    
    if($row_user) { // Check if user exists
        if (password_verify($password, $row_user['Password'])) {
            $_SESSION['atsmsaid'] = $row_user['ID'];
            echo "<script>alert('User logged in successfully!');</script>";
            echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
            exit(); // Exit script after redirection
        } else {
            echo "<script>alert('Invalid Details');</script>";
        }
    } else {
        // Check if the user exists in tbladmin with 'admin' permission
        $query_admin = mysqli_query($con, "SELECT ID, Password FROM tbladmin WHERE UserName='$adminuser' AND Permissions='admin'");
        if (!$query_admin) {
            die(mysqli_error($con)); // Check for query error
        }
        $row_admin = mysqli_fetch_assoc($query_admin);
        
        if($row_admin) { // Check if admin exists
            if (password_verify($password, $row_admin['Password'])) {
                $_SESSION['atsmsaid'] = $row_admin['ID'];
                echo "<script>alert('Admin logged in successfully!');</script>";
                echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
                exit(); // Exit script after redirection
            } else {
                echo "<script>alert('Invalid Details');</script>";
            }
        } else {
            // User not found in any table
            echo "<script>alert('Invalid Details');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Overseas Assignment Management System</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

    <style>
        body {
            background-image: url('images/image.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="index.php" style="font-size:24px;">
                                <img src='images/ecs1.jpg' width="70%" height="40%" align="center"><br>
                                Overseas Assignment Management System
                            </a>
                        </div>

                        <div class="login-form">
                            <form action="" method="post" name="login">
                                <div class="form-group">
                                    <label><strong>User Name</strong></label>
                                    <input class="au-input au-input--full" type="text" name="username" placeholder="User Name" required="true">
                                </div>
                                <div class="form-group">
                                    <label><strong>Password</strong></label>
                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password">
                                </div>
                                <div class="login-checkbox">
                                    <label>
                                        <a href="forgot-password.php"><strong>Forgotten Password?</strong></a>
                                    </label>
                                    <label>
                                        <a href="register.php"><strong>Register as a new User</strong></a>
                                    </label>
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit" name="login"><strong>sign in</strong></button>
                                <div class="social-login-content">
                                    <a href="../index.php"><strong>Back Home!!</strong></a>
                                </div>
                                <?php include_once('includes/footer.php');?>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>


