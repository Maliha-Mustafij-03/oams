<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
    exit; // Add exit after header redirect
} else {
    if (isset($_POST['submit'])) {
        // Sanitize form inputs to prevent SQL injection
        $Organization = mysqli_real_escape_string($con, $_POST['Organization']);
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $empid = mysqli_real_escape_string($con, $_POST['empid']);
        $emobilenumber = mysqli_real_escape_string($con, $_POST['emobilenumber']);
        $designation = mysqli_real_escape_string($con, $_POST['designation']);
        $educationalq = mysqli_real_escape_string($con, $_POST['educationalq']);
        $postingplace = mysqli_real_escape_string($con, $_POST['postingplace']);
        $typeofteam = mysqli_real_escape_string($con, $_POST['typeofteam']);
        $remark = mysqli_real_escape_string($con, $_POST['remark']);

        // Check if Organization is 'Others' and sanitize otherOrganization input
        if ($Organization === "Others") {
            $otherOrganization = mysqli_real_escape_string($con, $_POST['otherOrganization']);
            // Ensure otherOrganization is not empty
            if (!empty($otherOrganization)) {
                $Organization = $otherOrganization;
            }
        }

        // Check if Type of Team is 'Others' and sanitize othertypeofteam input
        if ($typeofteam === "Others") {
            $othertypeofteam = mysqli_real_escape_string($con, $_POST['othertypeofteam']);
            // Ensure othertypeofteam is not empty
            if (!empty($othertypeofteam)) {
                $typeofteam = $othertypeofteam;
            }
        }

        // Insert employee data into tblabroademp table
        $query_entry = mysqli_query($con, "INSERT INTO tblabroademp (Organization, Name, empid, emobilenumber, Designation, EducationalQ, postingplace, Typeofteam, Remark) VALUES ('$Organization', '$name', '$empid', '$emobilenumber', '$designation', '$educationalq', '$postingplace', '$typeofteam', '$remark')");

        if ($query_entry) {
            $entry_id = mysqli_insert_id($con);

            // Loop through visiting country details and insert into tbl_country_visits table
            if (isset($_POST['visiting_country'])) {
                $visiting_countries = $_POST['visiting_country'];
                $types_of_visit = $_POST['type_of_visit'];
                $go_nos = $_POST['go_no'];
                $total_dates = $_POST['total_date'];
                $visit_details = $_POST['visit_details'];
                $time_durations1 = $_POST['time_duration1'];
                $time_durations2 = $_POST['time_duration2'];

                for ($i = 0; $i < count($visiting_countries); $i++) {
                    $country = mysqli_real_escape_string($con, $visiting_countries[$i]);
                    $type_of_visit = mysqli_real_escape_string($con, $types_of_visit[$i]);
                    $go_no = mysqli_real_escape_string($con, $go_nos[$i]);
                    $total_date = mysqli_real_escape_string($con, $total_dates[$i]);
                    $visit_detail = mysqli_real_escape_string($con, $visit_details[$i]);
                    $time_duration1 = mysqli_real_escape_string($con, $time_durations1[$i]);
                    $time_duration2 = mysqli_real_escape_string($con, $time_durations2[$i]);

                    // Check if Visiting Country is 'Others' and sanitize other_country input
                    if ($country === "Others") {
                        $other_country = mysqli_real_escape_string($con, $_POST['other_country'][$i]);
                        // Ensure other_country is not empty
                        if (!empty($other_country)) {
                            $country = $other_country;
                        }
                    }

                    // Insert data into tbl_country_visits table
                    $query_country = mysqli_query($con, "INSERT INTO tbl_country_visits (entry_id, visited_country, type_of_visit, go_no, total_date, visit_details, time_duration1, time_duration2) VALUES ('$entry_id', '$country', '$type_of_visit', '$go_no', '$total_date', '$visit_detail', '$time_duration1', '$time_duration2')");

                    if (!$query_country) {
                        echo '<script>alert("Error in inserting visiting country data.")</script>';
                        exit;
                    }
                }
            }

            echo '<script>alert("Details have been added successfully.")</script>';
            echo "<script>window.location.href ='new-entry-form.php'</script>";
        } else {
            echo '<script>alert("Error in inserting employee data.")</script>';
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Management System || Entry Forms</title>
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <style>
        /* Custom Styles */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fc;
            font-size: 14px;
            font-weight: bold;
            color: #000;
        }

        .page-wrapper {
            min-height: 100vh;
            position: relative;
            background-color: #f8f9fc;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e73df;
            border-radius: 10px 10px 0 0;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
        }

        .card-body {
            padding: 40px;
        }

        .form-control {
            border-radius: 25px;
            height: 50px;
            font-size: 14px;
            padding-left: 25px;
            padding-right: 25px;
            color: #292b2c;
            font-weight: bold;
        }

        .btn-custom {
            border-radius: 25px;
            font-size: 14px;
            font-weight: bold;
            padding: 15px 30px;
        }

        .btn-back {
            background-color: #6c757d;
            color: #fff;
            border: none;
        }

        .btn-back:hover {
            background-color: #5a6268;
            color: #fff;
        }

        .btn-save {
            background-color: #4e73df;
            color: #fff;
            border: none;
        }

        .btn-save:hover {
            background-color: #4053af;
            color: #fff;
        }
    </style>
</head>


<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php include_once('includes/sidebar.php');?>
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include_once('includes/header.php');?>
            <?php include_once('includes/dashboard.php');?>
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div style="text-align: center; margin-bottom: 20px;">
                                        <img src="images/ec.jpg" alt="EC Image" style="max-width: 100px;">
                                    </div>
                                    <div class="card-header">
                                        <h3>প্রবাসে ভোটার নিবন্ধনের জন্য বাংলাদেশ নির্বাচন কমিশন ও আইডিয়া প্রকল্পের কর্মকর্তা ও কর্মচারীদের তালিকা</h3>
                                    </div>
                                    <div class="card-body card-block">
                                        <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="name" class="form-control-label">Name<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="name" name="name" placeholder="Enter Name" class="form-control" required="true">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-12 col-md-3">
                                                    <label for="empid" class="form-control-label">ID</label>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <input type="text" id="empid" name="empid" placeholder="Enter ID (e.g. xx-000)" class="form-control" pattern="[a-zA-Z0-9]+-[a-zA-Z0-9]+" title="Alphanumeric characters with a hyphen in the middle" maxlength="20">
                                                </div>
                                            </div>
                            <div class="row form-group">
                                <div class="col-md-12 mt-2">
                                <small id="countryHelp" class="form-text text-muted">If your country is not listed, please select "Others" and enter the country name in the text box.</small>
                            </div>
   <div id="visiting_countries">
                                                <div class="row form-group visiting_country">
                                                    <div class="col-12 col-md-4">
                                                        <label for="visit_country" class="form-control-label">Visiting Country</label>
                                                        <select name="visiting_country[]" class="form-control visiting_country_select" required>
                                                            <option value="" selected disabled>Select Visited Country</option>
                                                            <option value="KSA">KSA</option>
                                                            <option value="Kuwait">Kuwait</option>
                                                            <option value="Oman">Oman</option>
                                                            <!-- Add more options as needed -->
                                                            <option value="Others">Others</option>
                                                        </select>
                                                        <input type="text" class="form-control other_country" name="other_country[]" placeholder="Enter Other Country" style="display: none;">
                                                    </div>
                                                    <div class="col-12 col-md-4">
                                                        <label for="type_of_visit" class="form-control-label">Type of Visit</label>
                                                        <input type="text" class="form-control" name="type_of_visit[]" placeholder="Enter Type of Visit" required>
                                                    </div>
                                                    <div class="col-12 col-md-4">
                                                        <label for="go_no" class="form-control-label">GO No</label>
                                                        <input type="text" class="form-control" name="go_no[]" placeholder="Enter GO No" required>
                                                    </div>
                                                </div>
                                            </div>
                                             <div class="col-md-1 remove_country">
                                                        <button type="button" class="btn btn-danger">Remove</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Add More Button -->
                                            <div class="row form-group">
                                                <div class="col-12 col-md-6">
                                                    <button type="button" class="btn btn-secondary btn-sm add_more">Add More Visiting Country</button>
                                                </div>
                                            </div>
                                            
                                                
                                            </div>
                                            <!-- End Add more visiting countries -->
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="designation" class="form-control-label">Designation<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="designation" name="designation" placeholder="Enter Designation" class="form-control" required="true">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="educationalq" class="form-control-label">Educational Qualification</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="educationalq" name="educationalq" placeholder="Enter Educational Qualification" class="form-control">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="Organization" class="form-control-label">Organization<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select type="text" id="Organization" name="Organization" class="form-control" required="true" onchange="toggleOtherField(this.value)">
                                                        <option value="">Choose Organization</option>
                                                        <option value="Bangladesh Election Commission Secretariat">Bangladesh Election Commission Secretariat</option>
                                                        <option value="NID Wing">NID Wing</option>
                                                        <option value="IDEA Project (phase_2)">IDEA Project (Phase-2)</option>
                                                        <option value="Others">Others</option>
                                                    </select>
                                                    <div id="otherOrganizationField" style="display: none;">
                                                        <input type="text" id="otherOrganization" name="otherOrganization" placeholder="Enter Other Organization if it is not Listed here" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="postingplace" class="form-control-label">Posting Place<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="postingplace" name="postingplace" placeholder="Enter Posting Place" class="form-control" required="true">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="emobilenumber" class="form-control-label">Mobile Number</label>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <input type="text" id="emobilenumber" name="emobilenumber" placeholder="Enter Mobile Number" class="form-control">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="typeofteam" class="form-control-label">Type Of Visit<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select type="text" id="typeofteam" name="typeofteam" class="form-control" required="true">
                                                        <option value="">Choose Catagory</option>
                                                        <option value="Technical Team">Technical Team</option>
                                                        <option value="Admin Team">Admin Team</option>
                                                        <option value="Inauguration Team">Inauguration Team</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="remark" class="form-control-label">Remarks</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="remark" name="remark" placeholder="Enter Remarks" class="form-control">
                                                </div>
                                            </div>
                                             </div>
                                            <div class="card-footer">
                                                <p style="text-align: center;"><button type="submit" name="submit" id="submit" class="btn btn-primary btn-sm">Add</button></p>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include_once('includes/footer.php');?>
                </div>
            </div>
        </div>
    </div>
    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS -->
    <script src="vendor/slick/slick.min.js"></script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js"></script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
    <!-- Main JS-->
    <script src="js/main.js"></script>
    <!-- Add More Visiting Countries Script -->
    <script>
  
        $(document).ready(function () {
            // Add more visiting country fields
            $(".add_more").click(function () {
                var html = '<div class="row form-group visiting_country"> \
                                <div class="col-12 col-md-4"> \
                                    <label for="visit_country" class="form-control-label">Visiting Country</label> \
                                    <select name="visiting_country[]" class="form-control visiting_country_select" required> \
                                        <option value="" selected disabled>Select Visited Country</option> \
                                        <option value="KSA">KSA</option> \
                                        <option value="Kuwait">Kuwait</option> \
                                        <option value="Oman">Oman</option> \
                                        <!-- Add more options as needed --> \
                                        <option value="Others">Others</option> \
                                    </select> \
                                    <input type="text" class="form-control other_country" name="other_country[]" placeholder="Enter Other Country" style="display: none;"> \
                                </div> \
                                <div class="col-12 col-md-4"> \
                                    <label for="type_of_visit" class="form-control-label">Type of Visit</label> \
                                    <input type="text" class="form-control" name="type_of_visit[]" placeholder="Enter Type of Visit" required> \
                                </div> \
                                <div class="col-12 col-md-4"> \
                                    <label for="go_no" class="form-control-label">GO No</label> \
                                    <input type="text" class="form-control" name="go_no[]" placeholder="Enter GO No" required> \
                                </div> \
                                 <div class="col-md-2"> \
                            <input type="text" class="form-control" name="total_date[]" placeholder="Enter Total Date" required> \
                        </div> \
                        <div class="col-md-4"> \
                            <input type="text" class="form-control" name="visit_details[]" placeholder="Enter Visit Details" required> \
                        </div> \
                        <div class="col-md-2"> \
                            <input type="date" class="form-control" name="time_duration1[]" placeholder="Enter Time Duration" required> \
                        </div> \
                        <div class="col-md-2"> \
                            <input type="date" class="form-control" name="time_duration2[]" placeholder="Enter Time Duration" required> \
                        </div> \
                            </div>';
                $("#visiting_countries").append(html);
            });

            // Show/hide other country input based on selection
            $("body").on("change", ".visiting_country_select", function () {
                var selectedOption = $(this).val();
                var otherCountryInput = $(this).closest(".visiting_country").find(".other_country");
                if (selectedOption === "Others") {
                    otherCountryInput.show().prop('required', true);
                } else {
                    otherCountryInput.hide().prop('required', false);
                }
            });
        });
    
  


    function toggleOtherField(value) {
        var otherOrganizationField = $('#otherOrganizationField');
        if (value === "Others") {
            otherOrganizationField.show();
        } else {
            otherOrganizationField.hide();
        }
    }
    </script>
</body>

</html>
