<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
    exit();
} else {
    // Code for deletion
    if (isset($_GET['del'])) {
        // Check if the user has 'user' or 'admin' permissions
        $admin_id = $_SESSION['atsmsaid'];
        $check_permission_query = "SELECT Permissions FROM tbladmin WHERE ID='$admin_id'";
        $check_permission_result = mysqli_query($con, $check_permission_query);
        if ($check_permission_result) {
            $admin_row = mysqli_fetch_assoc($check_permission_result);
            if ($admin_row['Permissions'] == 'user' || $admin_row['Permissions'] == 'admin') {
                // User has 'user' or 'admin' permissions, proceed with deletion
                $atid = intval($_GET['del']);
                if (!$con) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                $query = mysqli_query($con, "DELETE FROM tblabroademp WHERE ID='$atid'");
                if ($query) {
                    echo "<script>alert('Successfully deleted entry');</script>";
                    echo "<script>window.location.href='manage-all-entry.php'</script>";
                    exit();
                } else {
                    echo "<script>alert('Something Went Wrong. Please try again.');</script>";
                    echo "<script>window.location.href='manage-all-entry.php'</script>";
                    exit();
                }
            } else {
                // User does not have 'user' or 'admin' permissions, redirect or display an error message
                header('location:logout.php'); // Redirect to logout page
                exit();
            }
        } else {
            // Error fetching user permissions, handle the error
            echo "<script>alert('Error fetching user permissions.');</script>";
            echo "<script>window.location.href='manage-all-entry.php'</script>";
            exit();
        }
    }
}

// Fetch admin permissions outside of the deletion code
$admin_id = $_SESSION['atsmsaid'];
$check_permission_query = "SELECT Permissions FROM tbladmin WHERE ID='$admin_id'";
$check_permission_result = mysqli_query($con, $check_permission_query);
if ($check_permission_result) {
    $admin_row = mysqli_fetch_assoc($check_permission_result);
} else {
    // Handle error if permission query fails
    echo "<script>alert('Error fetching user permissions.');</script>";
    echo "<script>window.location.href='manage-all-entry.php'</script>";
    exit();
}
?>

<!-- Rest of the HTML code remains unchanged -->



<?php
function breakText($text) {
    // Split the text into an array of words
    $words = explode(' ', $text);
    $newText = '';

    // Loop through the words
    for ($i = 0; $i < count($words); $i++) {
        // Add the current word to the new text
        $newText .= $words[$i];

        // Add a line break after every second word
        if (($i + 1) % 2 == 0) {
            $newText .= '<br>';
        } else {
            $newText .= ' '; // Add space between words
        }
    }

    return $newText;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Management System || Manage Entry</title>
   <!-- Include jQuery UI CSS for datepicker -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

    <!-- Custom CSS -->
    <style>
    .print-button {
        margin-bottom: 20px;
    }

  .table-earning {
    border-collapse: collapse;
    width: 100%;
}

.table-earning th,
.table-earning td {
    border: 1px solid #000; /* Change border color to black */
    padding: 8px;
    text-align: left;
    font-size: 18px !important; /* Adjust font size for table data */
     /*font-weight: bold; Make content bold */
    white-space: pre-wrap; /* Wrap text */
    overflow-wrap: break-word; /* Break word if exceeds width */
    word-break: break-all; /* Break long words */
    color: #000 !important; /* Set content color to black */
}
.table-earning th {
    background-color: #90EE90 !important;
    font-weight: bold !important;
    font-size: 23px !important; /* Adjust font size for table headers */
    color: black !important; /* Set font color */
}


.table-earning tr:nth-child(even) {
    background-color: #f8f9fa;
}

.table-earning tr:hover {
    background-color: #e9ecef;
}

/* Center align the heading */
h3 {
    text-align: center;
}

/* Align center for the card container */
.card {
    text-align: center;
}
.btn-danger {
    color: #fff;
    background-color: #dc3545;
    border-color: #dc3545;
    padding: 0.375rem 0.75rem;
    border-radius: 0.25rem;
    display: inline-flex;
    align-items: center;
}

.btn-danger i {
    margin-right: 5px; /* Add some space between the icon and text */
}
/* Style for all buttons */
.btn {
    padding: 0.375rem 0.75rem;
    border-radius: 0.25rem;
    display: inline-flex;
    align-items: center;
    margin-right: 5px; /* Add some space between the buttons */
}

/* Style for the edit button */
.btn-danger {
    color: #fff;
    background-color: #dc3545;
    border-color: #dc3545;
}

/* Style for the print button */
.btn-warning {
    color: #212529;
    background-color: #ffc107;
    border-color: #ffc107;
}

/* Style for the details button */
.btn-success {
    color: #fff;
    background-color: #28a745;
    border-color: #28a745;
}


</style>

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php include_once('includes/sidebar.php'); ?>
        <!-- END HEADER MOBILE-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include_once('includes/header.php'); ?>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p25">
                    <div class="container-fluid">
                        <!-- Heading Section -->
                        <div class="card">
                            <div style="text-align: center; margin-bottom: 20px;">
                                <img src="images/ec.jpg" alt="EC Image" style="max-width: 100px;">
                            </div>
                            <h3>Overseas Assignment Management System</h3>
                            <hr />
                        </div>

                        <!-- Table Section -->
                        <div class="row">
                            <div class="col-lg-12" style="margin-top:2%">
                                <button class="btn btn-primary print-button" onclick="printPage()">Print</button>

                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-earning">
                                        <thead>
                                            <tr>
                                                <th>S.NO</th>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th>Visited Country</th>
                                                <th>Organization</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($con) {
                                                $query = "SELECT e.ID, e.Designation, e.Name, e.Organization, GROUP_CONCAT(cv.visited_country) AS VisitedCountry 
                                                        FROM tblabroademp e 
                                                        LEFT JOIN tbl_country_visits cv ON e.ID = cv.entry_id 
                                                        GROUP BY e.ID";
                                                $result = mysqli_query($con, $query);
                                                $cnt = 1;
                                                while ($row = mysqli_fetch_array($result)) {
                                            ?>
                                                    <tr>
                                                        <td><?php echo $cnt; ?></td>
                                                        <td><?php echo breakText($row['Name']); ?></td>
                                                        <td><?php echo breakText($row['Designation']); ?></td>

                                                        
                                                        <td><?php echo $row['VisitedCountry']; ?></td>
                                                        <td><?php echo breakText($row['Organization']); ?></td>

                                                        <td>
                                                            <!-- Details button with details icon -->
<a href="all-entry-detail.php?editid=<?php echo $row['ID']; ?>" title="View Full Details" class="btn btn-success">
    <i class="fas fa-info-circle"></i> <!-- Details icon -->
</a>
                                                            <!-- Edit button with edit icon -->
<a href="auto-edit-detail.php?editid=<?php echo $row['ID']; ?>" title="View Edit" class="btn btn-danger">
    <i class="fas fa-edit"></i> <!-- Edit icon -->
</a>

<!-- Print button with print icon -->
<a href="print.php?vid=<?php echo $row['ID']; ?>" style="cursor:pointer" target="_blank"" title="Print Full Details" class="btn btn-warning">
    <i class="fas fa-print"></i> <!-- Print icon -->
</a>

<?php
                                                            // Check if the user has 'admin' permissions to display the delete button
                                                            if ($admin_row['Permissions'] == 'admin') {
                                                            ?>
                                                                <a href="#" 
   title="Delete Data" 
   onclick="if(confirm('Do you really want to delete the entry?')) { window.location.href = 'manage-all-entry.php?del=<?php echo $row['ID']; ?>'; } return false;" 
   class="btn btn-danger">
    <i class="fas fa-times"></i> <!-- Red cross sign icon -->
</a>

                                                            <?php
                                                            }
                                                            ?>

                                                        </td>
                                                    </tr>
                                            <?php
                                                    $cnt = $cnt + 1;
                                                }
                                            } else {
                                                echo "Database connection failed.";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php include_once('includes/footer.php'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main JS-->
    <script>
        function printPage() {
            window.print();
        }
    </script>

 <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
