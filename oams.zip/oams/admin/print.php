<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
} else {
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Include CSS styles -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background-color: #28a745;
            color: #fff;
            text-align: center;
            padding: 10px;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .footer {
            background-color: #ffc107;
            color: #333;
            text-align: center;
            padding: 10px;
            font-size: 18px;
            margin-top: 20px;
        }


       
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
            font-weight: bold;
            color: black;
            font-size: 18px;
        }

        th {
            background-color: #28a745;
            color: #fff;
            text-align: left;
        }

        td {
            background-color: #f8f9fa; 
            color: #555; 
        }

        .print-icon {
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container">
        <div style="text-align: center; margin-bottom: 20px;">
            <img src="images/ec.jpg" alt="EC Image" style="max-width: 200px;">
        </div>
        <div class="header">
            প্রবাসে ভোটার নিবন্ধনের জন্য বাংলাদেশ নির্বাচন কমিশন ও আইডিয়া প্রকল্পের কর্মকর্তা ও কর্মচারীদের তালিকা
        </div>
        <?php
        $cid = $_GET['vid'];
        $ret = mysqli_query($con, "SELECT ae.empid, ae.EntryDate, ae.Organization, ae.Name, ae.emobilenumber, ae.Designation, ae.EducationalQ, ae.postingplace, ae.Typeofteam, ae.Remark, GROUP_CONCAT(cv.visited_country) as visited_countries, GROUP_CONCAT(CONCAT(DATE_FORMAT(cv.time_duration1, '%d-%m-%Y'), ' to ', DATE_FORMAT(cv.time_duration2, '%d-%m-%Y'))) as time_durations FROM tblabroademp AS ae LEFT JOIN tbl_country_visits AS cv ON ae.ID = cv.entry_id WHERE ae.ID = '$cid' GROUP BY ae.ID");
        while ($row = mysqli_fetch_array($ret)) {
        ?>

            <table>
                <tr>
                    <th colspan="4">Details</th>
                </tr>
                <tr>
                    <th>ID Number</th>
                    <td><?php echo $row['empid']; ?></td>
                    <th>Organization</th>
                    <td><?php echo $row['Organization']; ?></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><?php echo $row['Name']; ?></td>
                    <th>Posting Place</th>
                    <td><?php echo $row['postingplace']; ?></td>
                </tr>
                <tr>
                    <th>Mobile Number</th>
                    <td><?php echo $row['emobilenumber']; ?></td>
                    <th>Designation</th>
                    <td><?php echo $row['Designation']; ?></td>
                </tr>
                <tr>
                    <th>Entry Time in Software</th>
                    <td><?php echo $row['EntryDate']; ?></td>
                    <th>Visited Countries</th>
                    <td><?php echo $row['visited_countries']; ?></td>
                </tr>
                <tr>
                    <th>Time Durations</th>
                    <td colspan="3"><?php echo $row['time_durations']; ?></td>
                </tr>
                <tr>
                    <th>Remark</th>
                    <td colspan="3"><?php echo $row['Remark']; ?></td>
                </tr>
                <tr>
                    <td colspan="4" style="text-align: center;">
                        <button class="fa fa-print fa-2x print-icon" onclick="window.print()"></button>
                    </td>
                </tr>
            </table>
        <?php } ?>

        <div class="footer">
            All rights reserved IDEA(Phase-2)
        </div>
    </div>
    <div style="text-align: center; margin-top: 20px;">
        <a href="manage-all-entry.php" class="btn btn-primary">Go Back</a>
    </div>
</body>

</html>

<?php } ?>
