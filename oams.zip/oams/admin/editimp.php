<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
    exit(); // Add exit after header to stop script execution
} else {
    if (isset($_POST['submit'])) {
        $eid = $_GET['editid'];

        // Retrieve form data
        $organization = $_POST['organization'];
        $name = $_POST['name'];
        $empid = $_POST['empid'];
        $emobilenumber = $_POST['emobilenumber'];
        $designation = $_POST['designation'];
        $educationalq = $_POST['educationalq'];
        $postingplace = $_POST['postingplace'];
        $remark = $_POST['remark'];
        $visited_countries = $_POST['visited_countries'];
        $type_of_visit = $_POST['type_of_visit'];
        $go_no = $_POST['go_no'];
        $total_dates = $_POST['total_date'];
        $visit_details = $_POST['visit_details'];
        $time_durations = $_POST['time_durations'];

        // Update the database record
        $query = mysqli_query($con, "UPDATE tblabroademp SET Organization='$organization', Name='$name', empid='$empid', emobilenumber='$emobilenumber', Designation='$designation', EducationalQ='$educationalq', postingplace='$postingplace', Remark='$remark' WHERE ID='$eid'");

        if ($query) {
            // Delete existing records for the entry ID
            mysqli_query($con, "DELETE FROM tbl_country_visits WHERE entry_id='$eid'");
            
            // Insert the new records for visited countries and time durations
            if (!empty($visited_countries)) {
                foreach ($visited_countries as $key => $country) {
                    $start_date = date('Y-m-d', strtotime($time_durations[$key][0]));
                    $end_date = date('Y-m-d', strtotime($time_durations[$key][1]));
                    $visit_type = $type_of_visit[$key];
                    $govt_order = $go_no[$key];
                    $total_days = $total_dates[$key];
                    $details = $visit_details[$key];
                    
                    mysqli_query($con, "INSERT INTO tbl_country_visits (entry_id, visited_country, type_of_visit, go_no, total_date, visit_details, time_duration1, time_duration2) VALUES ('$eid', '$country', '$visit_type', '$govt_order', '$total_days', '$details', '$start_date', '$end_date')");
                }
            }
            echo '<script>alert("Details have been updated successfully.")</script>';
        } else {
            echo '<script>alert("Something Went Wrong. Please try again.")</script>';
        }
    }

    $eid = $_GET['editid'];
    $query = "SELECT ae.ID, ae.empid, ae.EntryDate, ae.Organization, ae.Name, ae.emobilenumber, ae.Designation, ae.EducationalQ, ae.postingplace, ae.Typeofteam, ae.Remark, GROUP_CONCAT(DISTINCT cv.visited_country) as visited_countries, GROUP_CONCAT(CONCAT(DATE_FORMAT(cv.time_duration1, '%Y-%m-%d'), ',', DATE_FORMAT(cv.time_duration2, '%Y-%m-%d'))) as time_durations, GROUP_CONCAT(cv.type_of_visit) as type_of_visits, GROUP_CONCAT(cv.go_no) as go_nos, GROUP_CONCAT(cv.total_date) as total_dates, GROUP_CONCAT(cv.visit_details) as visit_details
              FROM tblabroademp AS ae
              LEFT JOIN tbl_country_visits AS cv ON ae.ID = cv.entry_id
              WHERE ae.ID = '$eid'
              GROUP BY ae.ID";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Management System Details</title>
    <!-- Include CSS files -->
    <?php include_once('includes/css.php'); ?>
    <!-- Additional Styles -->
    <style>
        /* Custom Styles */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fc;
            font-size: 16px;
            font-weight: bold;
            color: #000;
        }

        .mandatory {
            color: red;
        }

        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- Include sidebar -->
        <?php include_once('includes/sidebar.php'); ?>
        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- Include header -->
            <?php include_once('includes/header.php'); ?>
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h3>Edit Entry</h3>
                                    </div>
                                    <div class="card-body">
                                        <form method="post">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="organization">Organization<span class="mandatory">*</span></label>
                                                        <select name="organization" class="form-control" required>
                                                            <option value="">Select Organization</option>
                                                            <?php
                                                            $org_query = "SELECT DISTINCT Organization FROM tblabroademp";
                                                            $org_result = mysqli_query($con, $org_query);
                                                            while ($org_row = mysqli_fetch_assoc($org_result)) {
                                                                $selected = ($org_row['Organization'] == $row['Organization']) ? 'selected' : '';
                                                                echo "<option value='" . $org_row['Organization'] . "' $selected>" . $org_row['Organization'] . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="name">Name<span class="mandatory">*</span></label>
                                                        <input type="text" name="name" class="form-control" value="<?php echo $row['Name']; ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="empid">Employee ID</label>
                                                        <input type="text" name="empid" class="form-control" value="<?php echo $row['empid']; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="emobilenumber">Mobile Number</label>
                                                        <input type="text" name="emobilenumber" class="form-control" value="<?php echo $row['emobilenumber']; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label for="designation">Designation<span class="mandatory">*</span></label>
                                                        <input type="text" name="designation" class="form-control" value="<?php echo $row['Designation']; ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="educationalq">Educational Qualification</label>
                                                        <input type="text" name="educationalq" class="form-control" value="<?php echo $row['EducationalQ']; ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="postingplace">Posting Place<span class="mandatory">*</span></label>
                                                        <input type="text" name="postingplace" class="form-control" value="<?php echo $row['postingplace']; ?>" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="remark">Remark<span class="mandatory">*</span></label>
                                                        <input type="text" name="remark" class="form-control" value="<?php echo $row['Remark']; ?>" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Visited Countries -->
                                            <div class="form-group">
                                                <label for="visited_countries">Visited Countries</label>
                                                <div id="visiting_countries">
                                                    <?php
                                                    $visited_countries = explode(',', $row['visited_countries']);
                                                    $time_durations = explode(',', $row['time_durations']);
                                                    $type_of_visits = explode(',', $row['type_of_visits']);
                                                    $go_nos = explode(',', $row['go_nos']);
                                                    $total_dates = explode(',', $row['total_dates']);
                                                    $visit_details = explode(',', $row['visit_details']);
                                                    
                                                    foreach ($visited_countries as $key => $country) {
                                                        echo '<div class="form-group visiting_country">';
                                                        echo '<label for="visited_country_' . $key . '">Visited Country:</label>';
                                                        echo '<input type="text" name="visited_countries[]" class="form-control" value="' . $country . '" required>';
                                                        echo '</div>';
                                                        echo '<div class="form-group">';
                                                        echo '<label for="type_of_visit_' . $key . '">Type of Visit:</label>';
                                                        echo '<input type="text" name="type_of_visit[]" class="form-control" value="' . $type_of_visits[$key] . '" required>';
                                                        echo '</div>';
                                                        echo '<div class="form-group">';
                                                        echo '<label for="go_no_' . $key . '">GO No:</label>';
                                                        echo '<input type="text" name="go_no[]" class="form-control" value="' . $go_nos[$key] . '" required>';
                                                        echo '</div>';
                                                        echo '<div class="form-group">';
                                                        echo '<label for="total_date_' . $key . '">Total Days:</label>';
                                                        echo '<input type="text" name="total_date[]" class="form-control" value="' . $total_dates[$key] . '">';
                                                        echo '</div>';
                                                        echo '<div class="form-group">';
                                                        echo '<label for="visit_details_' . $key . '">Visit Details:</label>';
                                                        echo '<input type="text" name="visit_details[]" class="form-control" value="' . $visit_details[$key] . '">';
                                                        echo '</div>';
                                                        echo '<button type="button" class="btn btn-danger remove_country">Remove</button>';
                                                    }
                                                    ?>
                                                </div>
                                                <button type="button" id="add_more" class="btn btn-secondary">Add More Visiting Country</button>
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" name="submit" class="btn btn-primary">Update</button>
                                                <button type="button" onclick="goBack();" class="btn btn-secondary">Go Back</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Include footer -->
            <?php include_once('includes/footer.php'); ?>
        </div>
    </div>
    <!-- Include JS files -->
    <?php include_once('includes/js.php'); ?>
    <!-- Additional Scripts -->
    <script>
        // JavaScript code for adding and removing visiting country fields
        $(document).ready(function() {
            $('#add_more').click(function() {
                var html = '<div class="form-group visiting_country">';
                html += '<label for="visited_country">Visited Country:</label>';
                html += '<input type="text" name="visited_countries[]" class="form-control" required>';
                html += '</div>';
                html += '<div class="form-group">';
                html += '<label for="type_of_visit">Type of Visit:</label>';
                html += '<input type="text" name="type_of_visit[]" class="form-control" required>';
                html += '</div>';
                html += '<div class="form-group">';
                html += '<label for="go_no">GO No:</label>';
                html += '<input type="text" name="go_no[]" class="form-control" required>';
                html += '</div>';
                html += '<div class="form-group">';
                html += '<label for="total_date">Total Days:</label>';
                html += '<input type="text" name="total_date[]" class="form-control">';
                html += '</div>';
                html += '<div class="form-group">';
                html += '<label for="visit_details">Visit Details:</label>';
                html += '<input type="text" name="visit_details[]" class="form-control">';
                html += '</div>';
                html += '<button type="button" class="btn btn-danger remove_country">Remove</button>';

                $('#visiting_countries').append(html);
            });

            $(document).on('click', '.remove_country', function() {
                $(this).closest('.visiting_country').remove();
            });
        });

        // JavaScript function for "Go Back" button
        function goBack() {
            window.history.back();
            window.history.replaceState(null, document.title, window.location.href);
        }
    </script>
</body>

</html>
<?php } ?>
