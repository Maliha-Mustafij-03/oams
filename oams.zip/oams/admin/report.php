<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Title Page-->
    <title>Management System || Search</title>
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
<style>
    .table {
        border-collapse: collapse;
        width: 100%;
        border: 2px solid #000; /* Set border color to black */
        max-height: 500px; /* Adjust the maximum height of the table */
        overflow-y: auto; /* Add vertical scroll if the table height exceeds the max height */
    }

    /* Hide the Go Back button when printing */
    @media print {
        .form-group,
        .btn-primary,
        .btn-secondary { /* Hide the Go Back button */
            display: none !important;
        }
        
        #mainSearchForm {
            display: none;
        }

        /* Set the maximum number of rows per page */
        .table tbody tr:nth-child(14n+15) {
            page-break-before: always; /* Add page break before the 15th row and subsequent 14th rows */
        }

        /* Add bottom border to the last row of each printed page */
        @page {
            @bottom-center {
                border-bottom: 2px solid #000; /* Set bottom border color to black */
            }
        }
    }

    .table th,
    .table td {
        border: 1px solid #000; /* Set border color to black */
        text-align: left;
        padding: 8px;
        font-weight: bold; /* Make content bold */
        color: #000; /* Set content color to black */
        font-size: 14px; /* Set font size to 14px */
    }

    .table th {
        background-color: #f2f2f2;
    }

    .table th:last-child {
        border-bottom: 2px solid #000 !important; /* Set bottom border color to black */
    }

    .table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    .table tr:hover {
        background-color: #ddd;
    }

    .table-responsive {
        overflow-x: auto;
    }
</style>





        
   
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php include_once('includes/sidebar.php');?>
        <!-- END HEADER MOBILE-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include_once('includes/header.php');?>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div style="text-align: center; margin-bottom: 20px;">
                            <img src="images/ec.jpg" alt="EC Image" style="max-width: 100px;">
                        </div>
                        <h3 style="text-align: center;">Overseas Assignment Management System</h3>
                       
                       
<?php
    // Display search criteria if any non-empty field is filled
    if ((isset($_POST['search']) || isset($_POST['subsearch']))) {
        $searchCriteria = $_POST['searchdata'];
        $country = $_POST['country'];
        $typeofteam = $_POST['typeofteam'];
        
        // Check if any field is non-empty
        if (!empty(trim($searchCriteria)) || !empty(trim($country)) || !empty(trim($typeofteam))) {
            echo "<h3 style='text-align: center;'>Search Result for:";
            $criteriaCount = 0; // Initialize the count of filled fields
            
            // Display search criteria for each filled field
            if (!empty(trim($searchCriteria))) {
                echo " $searchCriteria";
                $criteriaCount++; // Increment the count of filled fields
            }
            if (!empty(trim($country))) {
                if ($criteriaCount > 0) {
                    echo ",";
                }
                echo " $country";
                $criteriaCount++; // Increment the count of filled fields
            }
            if (!empty(trim($typeofteam))) {
                if ($criteriaCount > 0) {
                    echo ",";
                }
                echo " $typeofteam";
            }
            echo "</h3>";
        }
    }
?>




                        <div class="row justify-content-center">
                            <div class="col-lg-6">
                                <div class="table-responsive table--no-card m-b-30">
                                    <!-- Main search form -->
                                    <form id="mainSearchForm" method="post" action="">
                                        <div class="form-group">
                                            <input type="text" name="searchdata" placeholder="Enter Keyword(s)" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <select name="country" class="form-control">
                                                <option value="">Select Country</option>
                                                <?php
                                                $query = "SELECT DISTINCT visited_country FROM tbl_country_visits";
                                                $result = mysqli_query($con, $query);
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<option value='" . $row['visited_country'] . "'>" . $row['visited_country'] . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
   <div class="form-group">
    <select name="typeofteam" class="form-control">
        <option value="">Select Type of Visit</option>
        <?php
        $query = "SELECT DISTINCT type_of_visit FROM tbl_country_visits";
        $result = mysqli_query($con, $query);

        // Check if query is successful
        if ($result) {
            // Loop through query results to populate dropdown options
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value='" . $row['type_of_visit'] . "'>" . $row['type_of_visit'] . "</option>";
            }
        } else {
            // Display error if query fails
            echo "<option value=''>Error fetching data</option>";
        }
        ?>
    </select>
</div>

</div>

                                        </div>
                                        <div class="form-group">
                                            <button type="submit" name="search" class="btn btn-primary btn-block">Search</button>
                                        </div>
                                    </form>
                                    <!-- End of main search form -->
                                </div>
                            </div>
                        </div>
                        <div id="searchResult" class="table-responsive table--no-card m-b-30">
                            <!-- Search result table -->
                            <?php
    if (isset($_POST['search'])) {
        $searchCriteria = $_POST['searchdata'];
        $country = $_POST['country'];
        $typeofteam = $_POST['typeofteam'];

        $query = "SELECT e.ID, e.empid, e.Organization, e.Name, e.EntryDate, e.Designation, e.Typeofteam, e.postingplace, GROUP_CONCAT(cv.visited_country) AS VisitedCountries, GROUP_CONCAT(cv.type_of_visit) AS TypeOfVisits
                FROM tblabroademp e 
                LEFT JOIN tbl_country_visits cv ON e.ID = cv.entry_id
                WHERE (e.Name LIKE '%$searchCriteria%' OR cv.visited_country LIKE '%$searchCriteria%' OR e.Designation LIKE '%$searchCriteria%' OR e.Organization LIKE '%$searchCriteria%' OR e.Typeofteam LIKE '%$searchCriteria%')
                AND (cv.visited_country LIKE '%$country%' OR '$country' = '')
                AND (cv.type_of_visit LIKE '%$typeofteam%' OR '$typeofteam' = '')
                GROUP BY e.ID";

        $result = mysqli_query($con, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            ?>
            <h3>Search Results:</h3>
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Organization</th>
                    <th>Visited Countries</th>
                    <th>Type of Visit</th>
                    <th>Designation</th>
                    <th>Posting Place</th>
                </tr>
                </thead>
                <tbody>

<?php
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row['ID']; ?></td>
                        <td><?php echo $row['empid']; ?></td>
                        <td><?php echo $row['Name']; ?></td>
                        <td><?php echo $row['Organization']; ?></td>
                        <td><?php echo $row['VisitedCountries']; ?></td>
                        <td><?php echo $row['TypeOfVisits']; ?></td>
                        <td><?php echo $row['Designation']; ?></td>
                        <td><?php echo $row['postingplace']; ?></td>
                    </tr>
                    
<?php
        $i++;
    }
?>
                                           
                                        </tbody>
                                  </table>
                                     &nbsp;

                                  <?php } else {
                                    echo "<p style='color:red; text-align:center;'>No record found!</p>";
                                }
                            }?>
                                  <!-- Add extra space -->
                                  <div style="height: 30px;"></div>
                  <!-- Print button -->
<div style="text-align: center; margin-bottom: 20px;">
    <button onclick="printContent();" class="btn btn-primary print-button">Print</button>
</div>              
               <!-- Go Back button -->
    <div style="text-align: center; margin-bottom: 20px;" class="ghosted">
       <button onclick="goBack();" class="btn btn-secondary">Go Back</button>
    </div>            

<script>
    function goBack() {
        window.location.replace(document.referrer);
    }
</script>




<!-- Main JS-->
<script src="js/main.js"></script>
<!-- Custom JS for printing -->
<script>
        function printContent() {
            alert('Print button clicked. Do you want to generate a report?');
            var printButton = document.querySelector('.print-button');
            printButton.style.display = 'none';
            window.print();
            printButton.style.display = 'block';
        }



</script>

        


</body>
</html>
<?php
}
?>

                                
                        </div>
                        <!-- End of search result table -->
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
        </div>
        <!-- END PAGE CONTAINER-->
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS -->
    <script src="vendor/slick/slick.min.js"></script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js"></script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js"></script>

    <!-- Main JS-->
    <script src="js/main.js"></script>
</body>
</html>
<?php

?>
