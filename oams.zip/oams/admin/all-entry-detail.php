<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
    exit();
} else {
    if (isset($_GET['editid'])) {
        $eid = $_GET['editid'];
        $query = "SELECT ae.empid, ae.EntryDate, ae.Organization, ae.Name, ae.emobilenumber, ae.Designation, ae.EducationalQ, ae.postingplace, ae.Remark, GROUP_CONCAT(cv.visited_country) as visited_countries, GROUP_CONCAT(cv.type_of_visit) as type_of_visits, GROUP_CONCAT(CONCAT(DATE_FORMAT(cv.time_duration1, '%d-%m-%Y'), ' to ', DATE_FORMAT(cv.time_duration2, '%d-%m-%Y'))) as time_durations,GROUP_CONCAT(cv.type_of_visit) as type_of_visit, GROUP_CONCAT(cv.go_no) as go_no, GROUP_CONCAT(cv.total_date) as total_dates, GROUP_CONCAT(cv.visit_details) as visit_details
                  FROM tblabroademp AS ae
                  LEFT JOIN tbl_country_visits AS cv ON ae.ID = cv.entry_id
                  WHERE ae.ID = '$eid'
                  GROUP BY ae.empid";

        $result = mysqli_query($con, $query);

        if ($result) {
            $row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management System Details</title>
    <!-- Include CSS files -->
    <!-- Include jQuery UI CSS for datepicker -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <?php include_once('includes/css.php');?>

    <style>
        /* Additional CSS styles */
        .card-body th,
        .card-body td {
            font-weight: bold;
            color: #000000;
            font-size: 20px;
        }

        .entry-details {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
        }
        .vertical-align-middle {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
        }
    </style>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- Include sidebar -->
        <?php include_once('includes/sidebar.php');?>
        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- Include header -->
            <?php include_once('includes/header.php');?>
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div style="text-align: center; margin-bottom: 20px;">
                                        <img src="images/ec.jpg" alt="EC Image" style="max-width: 100px;">
                                    </div>
                                    <div class="col-lg-12 vertical-align-middle">
                                        <h3>Overseas Assignment Management System</h3>
                                    </div>
                                    <div class="card-header">
                                        <strong class="entry-details">Employee Entry Details</strong>
                                    </div>
                                    <div class="card-body card-block">
                                        <table border="1" class="table table-bordered mg-b-0">
                                            <tr>
                                                <th>Employee ID</th>
                                                <td><?php echo $row['empid'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Entry Time in Software</th>
                                                <td><?php echo $row['EntryDate'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Organization</th>
                                                <td><?php echo $row['Organization'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Name</th>
                                                <td><?php echo $row['Name'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Mobile Number</th>
                                                <td><?php echo $row['emobilenumber'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Designation</th>
                                                <td><?php echo $row['Designation'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Educational Qualification</th>
                                                <td><?php echo $row['EducationalQ'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Posting Place</th>
                                                <td><?php echo $row['postingplace'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Visited Countries</th>
                                                <td><?php echo $row['visited_countries'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Visiting Remarks</th>
                                                <td><?php echo $row['visit_details'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Type of Visits</th>
                                                <td><?php echo $row['type_of_visits'];?></td>
                                            </tr>
                                            <tr>
                                                <th>GO No</th>
                                                <td><?php echo $row['go_no'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Total Days</th>
                                                <td><?php echo $row['total_dates'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Remark</th>
                                                <td><?php echo $row['Remark'];?></td>
                                            </tr>
                                            <tr>
                                                <th>Time Durations</th>
                                                <td><?php echo $row['time_durations'];?></td>
                                            </tr>
                                        </table>
                                        <div class="text-center">
                                            <button type="button" onclick="goBack();" class="btn btn-secondary">Go Back</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Include footer -->
        <?php include_once('includes/footer.php');?>
    </div>
<!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="js/main.js"></script>
    <!-- Include JS files -->
    <?php include_once('includes/js.php');?>

    <!-- JavaScript function for "Go Back" button -->
    <script>
        function goBack() {
            window.history.back();
            window.history.replaceState(null, document.title, window.location.href);
        }
    </script>
</body>

</html>

<?php
        } else {
            echo "Error fetching data from the database.";
        }
    } else {
        echo "Employee ID not provided.";
    }
}
?>
