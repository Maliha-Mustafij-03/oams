<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (empty($_SESSION['atsmsaid'])) {
    header('location:logout.php');
    exit; // Add exit after header redirect
} else {
    if (isset($_POST['submit'])) {
        // Sanitize inputs
        $Organization = $_POST['Organization'];
        $name = $_POST['name'];
        $empid = $_POST['empid'];
        $emobilenumber = $_POST['emobilenumber'];
        $designation = $_POST['designation'];
        $educationalq = $_POST['educationalq'];
        $postingplace = $_POST['postingplace'];
        $remark = $_POST['remark'];

        // Check if Organization is 'Others' and set otherOrganization input
        if ($Organization === "Others" && !empty($_POST['otherOrganization'])) {
            $Organization = $_POST['otherOrganization'];
        }

        // Insert employee data into tblabroademp table
        $insert_emp_sql = "INSERT INTO tblabroademp (Organization, Name, empid, emobilenumber, Designation, EducationalQ, postingplace, Remark) VALUES ('$Organization', '$name', '$empid', '$emobilenumber', '$designation', '$educationalq', '$postingplace', '$remark')";
              


        if ($result_emp) {
            $entry_id = mysqli_insert_id($con);

            // Loop through visiting country details and insert into tbl_country_visits table
            if (isset($_POST['visiting_country'])) {
                $visiting_countries = $_POST['visiting_country'];
                $types_of_visit = $_POST['type_of_visit'];
                $go_nos = $_POST['go_no'];
                $total_dates = $_POST['total_date'];
                $visit_details = $_POST['visit_details'];
                $time_durations1 = $_POST['time_duration1'];
                $time_durations2 = $_POST['time_duration2'];
                $other_type_of_visit = $_POST['other_type_of_visit'];

                for ($i = 0; $i < count($visiting_countries); $i++) {
                    $country = $visiting_countries[$i];
                    $type_of_visit = $types_of_visit[$i];
                    $go_no = $go_nos[$i];
                    $total_date = $total_dates[$i];
                    $visit_detail = $visit_details[$i];
                    $time_duration1 = $time_durations1[$i];
                    $time_duration2 = $time_durations2[$i];

                    // Check if Visiting Country is 'Others' and set other_country input
                    if ($country === "Others" && !empty($_POST['other_country'][$i])) {
                        $country = $_POST['other_country'][$i];
                    }

                    // Check if Type of Visit is 'Others' and set other_type_of_visit input
                    if ($type_of_visit === "Others" && !empty($other_type_of_visit[$i])) {
                        $type_of_visit = $other_type_of_visit[$i];
                    }

                    // Insert visiting country data into tbl_country_visits table
                    $insert_country_sql = "INSERT INTO tbl_country_visits (entry_id, visited_country, type_of_visit, go_no, total_date, visit_details, time_duration1, time_duration2) VALUES ($entry_id, '$country', '$type_of_visit', '$go_no', $total_date, '$visit_detail', '$time_duration1','$time_duration2')";
                    //echo "$insert_country_sql";       
                 $result_country = mysqli_query($con, $insert_country_sql);

                    if (!$result_country) {
                        echo '<script>alert("Error in inserting visiting country data.")</script>';
                        exit;
                    }
                }
            }

            echo '<script>alert("Details have been added successfully.")</script>';
            echo "<script>window.location.href ='new-entry-form.php'</script>";
        } else {
            echo '<script>alert("Error in inserting employee data.")</script>';
            echo "<script>window.location.href ='new-entry-form.php'</script>";
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title Page-->
    <title>Management System || Entry Forms</title>
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <style>
        /* Custom Styles */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fc;
            font-size: 14px;
            font-weight: bold;
            color: #000;
        }

        .page-wrapper {
            min-height: 100vh;
            position: relative;
            background-color: #f8f9fc;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #4e73df;
            border-radius: 10px 10px 0 0;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
        }

        .card-body {
            padding: 40px;
        }

        .form-control {
            border-radius: 25px;
            height: 50px;
            font-size: 14px;
            padding-left: 25px;
            padding-right: 25px;
            color: #292b2c;
            font-weight: bold;
        }

        .btn-custom {
            border-radius: 25px;
            font-size: 14px;
            font-weight: bold;
            padding: 15px 30px;
        }

        .btn-back {
            background-color: #6c757d;
            color: #fff;
            border: none;
        }

        .btn-back:hover {
            background-color: #5a6268;
            color: #fff;
        }

        .btn-save {
            background-color: #4e73df;
            color: #fff;
            border: none;
        }

        .btn-save:hover {
            background-color: #4053af;
            color: #fff;
        }

        .remove-country {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 5px;
            /* Adjust the margin-top value to move the icon downward */
        }

        .remove-icon {
            font-size: 2em;
            /* Adjust the font size of the icon */
            cursor: pointer;
            margin-top: 42px;
        }
.vertical-align-middle {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
        }
    </style>
    </style>
</head>


<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php include_once('includes/sidebar.php');?>
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include_once('includes/header.php');?>
            <?php include_once('includes/dashboard.php');?>
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div style="text-align: center; margin-bottom: 20px;">
                                        <img src="images/ec.jpg" alt="EC Image" style="max-width: 100px;">
                                    </div>
                                    <div class="col-lg-12 vertical-align-middle">

                                        <h3>Overseas Assignment Management System</h3>
                                    </div>
                                    <div class="card-body card-block">
                                        <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="name" class="form-control-label">Name<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <div class="col-12 col-md-9">
    <input type="text" id="name" name="name" placeholder="Enter Name" class="form-control" required="true" pattern="[a-zA-Z\s'.]+" title="Please enter only letters, spaces, apostrophes, and periods.">

</div>

                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-12 col-md-3">
                                                    <label for="empid" class="form-control-label">ID</label>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <input type="text" id="empid" name="empid" placeholder="Enter ID (e.g. xx-000)" class="form-control" pattern="[a-zA-Z0-9]+-[a-zA-Z0-9]+" title="Alphanumeric characters with a hyphen in the middle" maxlength="20">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-md-12 mt-2">
                                                    <small id="countryHelp" class="form-text text-muted">If your country is not listed, please select "Others" and enter the country name in the text box.</small>
                                                </div>
                                                <div id="visiting_countries">
                                                    <div class="row form-group visiting_country">
                                                        <div class="col-12 col-md-4">
                                                            <label for="visit_country" class="form-control-label">Visiting Country</label>
                                                            <select name="visiting_country[]" class="form-control visiting_country_select" required>
                                                                <option value="" selected disabled>Select Visited Country</option>
                                                                <option value="KSA">KSA</option>
                                                                <option value="Kuwait">Kuwait</option>
                                                                <option value="Oman">Oman</option>
                                                                <option value="KSA">KSA</option>
                                                                <option value="Kuwait">Kuwait</option>
                                                                <option value="Oman">Oman</option>
                                                                <option value="Malaysia">Malaysia</option>
                                                                <option value="UK">UK</option>
                                                                <option value="Qatar">Qatar</option>
                                                                <option value="Bahrain">Bahrain</option>
                                                                <option value="Jordan">Jordan</option>
                                                                <option value="Italy">Italy</option>
                                                                <option value="Singapore">Singapore</option>
                                                                <option value="Lebanon">Lebanon</option>
                                                                <option value="Libiya">Libiya</option>
                                                                <option value="Australia">Australia</option>
                                                                <option value="Maldives">Maldives</option>
                                                                <option value="Canada">Canada</option>
                                                                <option value="UAE">Thailand</option>
                                                                <option value="UAE">Vietnam</option>
                                                                <option value="UAE">UAE</option>
                                                                <!-- Add more options as needed -->
                                                                <option value="Others">Others</option>
                                                            </select>
                                                            <input type="text" class="form-control other_country" name="other_country[]" placeholder="Enter Other Country" style="display: none;">
                                                        </div>
                                                        <div class="col-12 col-md-3">
                                                            <label for="type_of_visit" class=" form-control-label">Type of Visit</label>
                                                            <select class="form-control type_of_visit" name="type_of_visit[]" required>
                                                                <option value="" selected disabled>Select Type of Visit</option>
                                                                <option value="Admin Team">Admin Team</option>
                                                                <option value="Technical Team">Technical Team</option>
                                                                <option value="Inaugration Team">Inaugration Team</option>
                                                                <option value="PSI">PSI</option>
                                                                <option value="Training">Training</option>
                                                                <option value="Seminar">Seminar</option>
                                                                <option value="Others">Others</option>
                                                            </select>
                                                            <input type="text" class="form-control other_type_of_visit" name="other_type_of_visit[]" placeholder="Enter Type of Visit" style="display: none;" required>
                                                        </div>
                                                        <div class="col-12 col-md-4">
                                                            <label for="go_no" class="form-control-label">GO No</label>
                                                            <input type="text" class="form-control" name="go_no[]" placeholder="Enter GO No" >
                                                            &nbsp;
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label for="total_dates" class="form-control-label">Total days</label>
                                                            <input type="text" class="form-control" name="total_date[]" placeholder="Enter Total Days" >
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="visit_details" class="form-control-label">Visit Remarks</label>
                                                            <input type="text" class="form-control" name="visit_details[]" placeholder="Enter Visit Details" >
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label for="time_duration1" class="form-control-label">Start Date</label>
                                                            <input type="date" class="form-control" name="time_duration1[]" placeholder="Enter Time Duration" required>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label for="time_duration2" class="form-control-label">End Date</label>
                                                            <input type="date" class="form-control" name="time_duration2[]" placeholder="Enter Time Duration" required>
                                                        </div>

                                                        <div class="col-md-1 remove_country">
                                                            <i class="fas fa-times-circle text-danger remove-icon" style="cursor: pointer;"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Add More Button -->
                                                <div class="row form-group">
                                                    <div class="col-12 col-md-6">
                                                        <button type="button" class="btn btn-secondary btn-sm add_more">Add More Visiting Country</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- End Add more visiting countries -->

                                               <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="emobilenumber" class="form-control-label">Mobile Number</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="emobilenumber" name="emobilenumber" placeholder="Enter Mobile Number" class="form-control">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="designation" class="form-control-label">Designation<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="designation" name="designation" placeholder="Enter Designation" class="form-control" required="true">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="Organization" class="form-control-label">Organization<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select type="text" id="Organization" name="Organization" class="form-control" required="true" onchange="toggleOtherField(this.value)">
                                                        <option value="">Choose Organization</option>
                                                        <option value="Bangladesh Election Commission">Bangladesh Election Commission</option>
                                                        <option value="Election Commission Secretariat">Election Commission Secretariat </option>
                                                        
                                                        <option value="NID Wing">NID Wing</option>
                                                        <option value="IDEA Project(Phase-2)">IDEA Project(Phase-2)</option>
                                                        <option value="ICT Wing">ICT Wing</option>
                                                        <option value="Others">Others</option>
                                                    </select>
                                                    <div id="otherOrganizationField" style="display: none;">
                                                        <input type="text" id="otherOrganization" name="otherOrganization" placeholder="Enter Other Organization if it is not Listed here" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="educationalq" class="form-control-label">Educational Qualification</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="educationalq" name="educationalq" placeholder="Enter Educational Qualification" class="form-control" >
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="postingplace" class="form-control-label">Posting Place<span class="mandatory">*</span></label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="postingplace" name="postingplace" placeholder="Enter Posting Place" class="form-control" required="true">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="remark" class="form-control-label">Remark</label>
                                                </div>

                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="remark" name="remark" placeholder="Enter Remark" class="form-control" >
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-md-12 text-center">
                                                    <button type="submit" class="btn btn-save btn-lg" name="submit">Save</button>
                                                    <a href="dashboard.php" class="btn btn-back btn-lg">Back</a>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->
        </div>
        <!-- Include footer -->
        <?php include_once('includes/footer.php'); ?>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="js/main.js"></script>
    <script>
        $(document).ready(function () {
            // Toggle visibility of other_country input based on the selection of visiting_country
            $('body').on('change', '.visiting_country_select', function () {
                var selectedCountry = $(this).val();
                var otherCountryInput = $(this).closest('.visiting_country').find('.other_country');
                if (selectedCountry === 'Others') {
                    otherCountryInput.show().attr('required', true);
                } else {
                    otherCountryInput.hide().attr('required', false);
                }
            });

            // Toggle visibility of other_type_of_visit input based on the selection of type_of_visit
            $('body').on('change', '.type_of_visit', function () {
                var selectedTypeOfVisit = $(this).val();
                var otherTypeOfVisitInput = $(this).closest('.visiting_country').find('.other_type_of_visit');
                if (selectedTypeOfVisit === 'Others') {
                    otherTypeOfVisitInput.show().attr('required', true);
                } else {
                    otherTypeOfVisitInput.hide().attr('required', false);
                }
            });

            // Add more visiting country fields
            $('body').on('click', '.add_more', function () {
                var visitingCountryRow = $('#visiting_countries .visiting_country:first').clone();
                visitingCountryRow.find('input, select').val('');
                visitingCountryRow.find('.other_country').hide().attr('required', false);
                visitingCountryRow.find('.other_type_of_visit').hide().attr('required', false);
                $('#visiting_countries').append(visitingCountryRow);
            });

           


// Remove visiting country fields
    $('body').on('click', '.remove-icon', function () {
        var visitingCountryRow = $(this).closest('.visiting_country');
        // Check if this is the only visiting country field left
        if ($('#visiting_countries .visiting_country').length > 1) {
            visitingCountryRow.remove();
        } else {
            // If it's the only field left, just hide it instead of removing
            visitingCountryRow.find('input, select').val('');
            visitingCountryRow.find('.other_country').hide().attr('required', false);
            visitingCountryRow.find('.other_type_of_visit').hide().attr('required', false);
        }
    });
});

function toggleOtherField(value) {
        var otherOrganizationField = $('#otherOrganizationField');
        if (value === "Others") {
            otherOrganizationField.show();
        } else {
            otherOrganizationField.hide();
        }
    }
    </script>
</body>

</html>

