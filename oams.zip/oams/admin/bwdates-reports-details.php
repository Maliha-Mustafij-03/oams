
<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
    exit();
} else {
    // Code for deletion
    if (isset($_GET['del'])) {
        $atid = intval($_GET['del']);
        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $query = mysqli_query($con, "DELETE FROM tblabroademp WHERE ID='$atid'");
        if ($query) {
            echo "<script>alert('Successfully deleted entry');</script>";
            echo "<script>window.location.href='manage-all-entry.php'</script>";
            exit();
        } else {
            echo "<script>alert('Something Went Wrong. Please try again.');</script>";
            echo "<script>window.location.href='manage-all-entry.php'</script>";
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Title Page-->
    <title>Management System || Manage Entry</title>
    <!-- Font Awesome -->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

    <!-- Custom CSS -->
    <style>
        .print-button {
            margin-bottom: 20px;
        }

        /* Reduce row spacing */
        .table tbody tr {
            height: 30px;
        }

        /* Align center */
        h3 {
            text-align: center;
        }
    </style>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php include_once('includes/sidebar.php'); ?>
        <!-- END HEADER MOBILE-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php include_once('includes/header.php'); ?>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p25">
                    <div class="container-fluid">
                        <div class="row">
                            <h3>প্রবাসে ভোটার নিবন্ধনের জন্য বাংলাদেশ নির্বাচন কমিশন ও আইডিয়া প্রকল্পের কর্মকর্তা ও কর্মচারীদের তালিকা</h3>
                            <hr />
                            <div class="col-lg-6" style="margin-top:2%">
                                <form method="post" name="search">
                                    <input type="date" class="form-control" name="fromdate" id="fromdate" required="true">
                                    <input type="date" class="form-control mt-3" name="todate" id="todate" required="true">
                                    <button type="submit" class="btn btn-primary mt-3">Search</button>
                                </form>
                                <button class="btn btn-primary print-button mt-3" onclick="window.print()">Print</button>
                            </div>
                                <div class="col-lg-12" style="margin-top:2%">
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>S.NO</th>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th>Visited Country</th>
                                                <th>Organization</th>
                                                
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                                $fdate = $_POST['fromdate'];
                                                $tdate = $_POST['todate'];
                                                $ret = mysqli_query($con,"SELECT * FROM tblabroademp WHERE DATE(EntryDate) BETWEEN '$fdate' AND '$tdate'");
                                                $cnt = 1;
                                                while ($row = mysqli_fetch_array($ret)) {
                                            ?>
                                            <tr>
                                                <td><?php echo $cnt; ?></td>
                                                <td><?php echo $row['Name']; ?></td>
                                                <td><?php echo $row['Designation']; ?></td>
                                                <td><?php echo $row['VisitedCountry']; ?></td>
                                                <td><?php echo $row['Organization']; ?></td>
                                                
                                                <td>
                                                    <a href="all-entry-detail.php?editid=<?php echo $row['ID']; ?>" title="View Full Details" class="btn btn-success">Details</a>
                                                    <a href="auto-edit-detail.php?editid=<?php echo $row['ID']; ?>" title="View Edit" class="btn btn-danger">Edit</a>
                                                    <a href="print.php?vid=<?php echo $row['ID']; ?>" style="cursor:pointer" target="_blank" class="btn btn-warning">Print</a>
                                                    <a href="manage-all-entry.php?del=<?php echo $row['ID']; ?>" onclick="return confirm('Do you really want to delete the entry?');" class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                            <?php
                                                $cnt = $cnt + 1;
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php include_once('includes/footer.php'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
