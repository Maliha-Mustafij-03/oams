<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
    exit();
}

function getPageVisitCount($con)
{
    $today = date('Y-m-d');
    $query = mysqli_query($con, "SELECT visit_count FROM tbl_page_visits WHERE visit_date = '$today'");
    $row = mysqli_fetch_assoc($query);
    return $row['visit_count'];
}

//Update the page visit count
$visit_count = getPageVisitCount($con);
if ($visit_count === null) {
    mysqli_query($con, "INSERT INTO tbl_page_visits (visit_date, visit_count) VALUES (CURDATE(), 1)");
    $visit_count = 1;
} else {
    mysqli_query($con, "UPDATE tbl_page_visits SET visit_count = visit_count + 1 WHERE visit_date = CURDATE()");
    $visit_count += 1;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management System || Dashboard</title>
    <!-- Include jQuery UI CSS for datepicker -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
       <style>
        /* Additional Styles */
        {
            background-color: #0b6623 !important; /* Bottle green background color */
        }

        .main-content {
            
            height: calc(100vh - 120px); /* Adjust height accordingly */
        }




/* Additional Styles */
        .main-content {
            height: calc(100vh - 120px); /* Adjust height accordingly */
        }

        .digital-clock {
            font-size: 40px; /* Adjust font size */
            color: white !important; /* color for digital clock */
            text-align: left;
            margin-bottom: 20px;
        }

        .card-link {
            color: #fff !important; /* White color */
            text-decoration: none;
        }

        .card-link:hover {
            text-decoration: underline;
        }

        .card {
    background: linear-gradient(to right top, #b3ffd9, #d6ffd1, #f1ffc9, #fffabb, #ffe6a6); /* Gradient background */
    margin-bottom: 20px;
    padding: 16px;
    border-radius: 10px;
    border: none;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */
}

.card-body {
    border: 2px solid #d4d4d4; /* Light gray border */
    border-radius: 8px;
    padding: 5px; /* Decreased padding */
    background-color: #fff; /* White background color */
}

.card-title {
    color: #333; /* Dark text color */
    font-size: 24px;
    margin-bottom: 15px;
}

.count {
    color: #333; /* Dark text color */
    font-size: 36px;
    margin-bottom: 15px;
}

.card-body p {
    color: #555; /* Slightly darker text color */
    font-size: 14px;
    margin-bottom: 0; /* Remove margin bottom to avoid extra space */
}


        .footer {
            background-color: #4CAF50; /* Green footer background color */
            color: #fff;
            padding: 10px 0;
        }

        .visit-count {
            color: yellow !important;
            font-size: 28px !important;
        }

        .green-card {
            background-color: #4CAF50;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .green-card p {
            color: #fff;
            margin: 0;
        }
/* CSS for the page size */
.page-container {
    transition: all 0.3s ease; /* Add transition for smooth resizing */
}




        .page-container {
    background-image: url('images/img2.jpg') !important; /* background image */
    background-size: cover; /* Cover the entire container */
      height: 140vh; /* Set height to fill the viewport */
    width: 100%;   /* Set width to fill the viewport */
    background-repeat: no-repeat; /* Do not repeat the image */

}

#clock-container {
    position: relative;
    display: flex;
    justify-content: right; /* Align right  */
    align-items: right; /* Align right */
}

#clock {
    width: 215px;
    height: 215px;
    border-radius: 50%;
    box-shadow: 0px 0px 3px rgba(0, 0, 0, 0.9);
    position: relative; /* Added position relative */
    margin-left: 20px; /* Adjusted margin to position it 20px from the left */
    margin-top: 20px; /* Adjusted margin to position it 20px from the top */
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #1c2731;
    /*background: radial-gradient(ellipse, #506068, #1c2731);*/
    background: linear-gradient(170deg, rgba(49, 57, 73, 0.8) 20%, rgba(49, 57, 73, 0.5) 20%, rgba(49, 57, 73, 0.5) 35%, rgba(41, 48, 61, 0.6) 35%, rgba(41, 48, 61, 0.8) 45%, rgba(31, 36, 46, 0.5) 45%, rgba(31, 36, 46, 0.8) 75%, rgba(49, 57, 73, 0.5) 75%), linear-gradient(45deg, rgba(20, 24, 31, 0.8) 0%, rgba(41, 48, 61, 0.8) 50%, rgba(82, 95, 122, 0.8) 50%, rgba(133, 146, 173, 0.8) 100%) #313949;
}


#clock span {
    position: absolute;
    transform: rotate(calc(30deg * var(--i)));
    inset: 12px;
    text-align: center;
}

#clock span i {
    transform: rotate(calc(-30deg * var(--j)));
    display: inline-block;
    font-size: 20px;
    font-style: normal;
    text-shadow: 1px 1px 0px rgb(0 0 0 / 25%);
    color: #ffffff;
}

#clock::after {
    content: '';
    position: absolute;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #fff;
    z-index: 2;
    opacity: 0.6;
}

#clock .hand {
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: flex-end;
}

#clock .hand i {
    position: absolute;
    background-color: var(--color);
    width: var(--width);
    height: var(--height);
    border-radius: 8px;
}

       .scrolling-text {
    height: 200px; /* Adjust height as needed */
    overflow-y: auto;
    border: 1px solid #ccc; /* Optional: Add border for aesthetics */
    padding: 5px;
    background-color: #0b6623 !important; /*  background color */
}

.scrolling-text p {
    margin: 0;
    color: yellow !important; /* Set text color to yellow */
}

#marquee-container {
    background-color: #000080 !important; /* Bottle green background color */
}

#marquee-container div {
    font-size: 30px; /* Font size of 30px */
    font-weight: bold;
    color: yellow !important; /* Yellow color */
}


    </style>
</head>

<body>
    <div class="page-wrapper">
        <!-- SIDEBAR -->
        <?php include_once('includes/sidebar.php');?>
        <!-- END SIDEBAR -->
        <!-- PAGE CONTAINER -->
        <div class="page-container">
            <!-- HEADER -->
            <?php include_once('includes/header.php');?>
            <!-- END HEADER -->
            <!-- MAIN CONTENT -->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    
                    <div class="container-fluid">
                        <div class="card-header" style="text-align: center;">
   <div id="marquee-container">
    <!-- Marquee tag with initial content -->
   
        
        <div> Overseas Assignment Management System</div>
        
        
    
</div>


    <script>
        // Function to update the marquee content
        function updateMarquee() {
            // Get the marquee element
            var marquee = document.getElementById('marquee');
            // Get the container element
            var container = document.getElementById('marquee-container');
            // Get all scrolling lines
            var lines = container.querySelectorAll('div');
            var index = 0;

            // Function to scroll the next line
            function scrollNextLine() {
                // Update marquee content with the current line
                marquee.innerHTML = lines[index].outerHTML;

                // Increment index or reset to 0 if it's the last line
                index = (index + 1) % lines.length;

                // Wait for a short duration before scrolling the next line
                setTimeout(scrollNextLine, 2500); // Adjust scroll speed (milliseconds)
            }

            // Start scrolling
            scrollNextLine();
        }

        // Call the function when the page is loaded 
        window.onload = updateMarquee;
    </script>
</div>


                       


        
    
    <script>
        function updateClock() {
            const now = new Date();
            const second = now.getSeconds();
            const minute = now.getMinutes();
            const hour = now.getHours();
            document.getElementById('hour').style.transform = `rotate(${30 * hour + minute / 2}deg)`;
            document.getElementById('minute').style.transform = `rotate(${6 * minute}deg)`;
            document.getElementById('second').style.transform = `rotate(${6 * second}deg)`;
        }
        setInterval(updateClock, 1000);
        updateClock();
    </script>

<body>
<div id="clock-container">
    <div id="clock">
        <div id="hour" class="hand" style="--color: #ff3d58; --height: 76px; --width: 4px"><i></i></div>
        <div id="minute" class="hand" style="--color: #00a6ff; --height: 86px; --width: 3px"><i></i></div>
        <div id="second" class="hand" style="--color: #ffffff; --height: 96px; --width: 2px"><i></i></div>
        <span style="--i: 1; --j: 0"><i>|</i></span>
        <span style="--i: 2; --j: 0"><i>|</i></span>
        <span style="--i: 3; --j: 3"><i>3</i></span>
        <span style="--i: 4; --j: 0"><i>|</i></span>
        <span style="--i: 5; --j: 0"><i>|</i></span>
        <span style="--i: 6; --j: 6"><i>6</i></span>
        <span style="--i: 7; --j: 0"><i>|</i></span>
        <span style="--i: 8; --j: 0"><i>|</i></span>
        <span style="--i: 9; --j: 9"><i>9</i></span>
        <span style="--i: 10; --j: 0"><i>|</i></span>
        <span style="--i: 11; --j: 0"><i>|</i></span>
        <span style="--i: 12; --j: 12"><i>12</i></span>
    </div>
</div>
</body>
</html>

                        <!-- DIGITAL CLOCK -->
                        <div class="digital-clock mb-4"></div>
                        <!-- END DIGITAL CLOCK -->
                        <!-- VISIT COUNT -->
                        <div class="row">
                            <div class="col-md-12">

                                <div class="green-card">
                                <p class="visit-count">This page has been visited <?php echo isset($visit_count) ? $visit_count : 0; ?> times today.</p>
                            </div></div>
                        </div>
                        <!-- END VISIT COUNT -->
                        <!-- CONTENT -->
                        <div class="row">
                            <!-- Today's Entry -->
                            <div class="col-md-4">
                                <a href="today-all-entry.php" class="card-link">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Today's Entry</h5>
                                            <h2 class="count">
                                                <?php
                                                $query_today = mysqli_query($con, "SELECT ID FROM tblabroademp WHERE DATE(EntryDate) = CURDATE()");
                                                echo mysqli_num_rows($query_today);
                                                ?>
                                            </h2>
                                            <p>Click here to view today's entry.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- Yesterday's Entry -->
                            <div class="col-md-4">
                                <a href="yesterday-all-entry.php" class="card-link">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Yesterday's Entry</h5>
                                            <h2 class="count">
                                                <?php
                                                $query_yesterday = mysqli_query($con, "SELECT ID FROM tblabroademp WHERE DATE(EntryDate) = CURDATE() - INTERVAL 1 DAY");
                                                echo mysqli_num_rows($query_yesterday);
                                                ?>
                                            </h2>
                                            <p>Click here to view yesterday's entry.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- Total Entry -->
                            <div class="col-md-4">
                                <a href="manage-all-entry.php" class="card-link">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Total Entry</h5>
                                            <h2 class="count">
                                                <?php
                                                $query_total = mysqli_query($con, "SELECT ID FROM tblabroademp");
                                                echo mysqli_num_rows($query_total);
                                                ?>
                                            </h2>
                                            <p>Click here to view total entry till date.</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- END CONTENT -->
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT -->
            <!-- FOOTER -->
            <footer class="footer text-center">
                <?php include_once('includes/footer.php'); ?>
            </footer>
            <!-- END FOOTER -->
        </div>
        <!-- END PAGE CONTAINER -->
    </div>

    <!-- jQuery -->
    
    <!-- Digital Clock Script -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <!-- Custom JavaScript -->
 <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="js/main.js"></script>
    
    
    <!-- Digital Clock -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script>
    function updateClock() {
        var now = moment().format('DD-MM-YYYY h:mm:ss A'); // Format with 12-hour AM/PM format
        document.querySelector('.digital-clock').textContent = now;
    }
    setInterval(updateClock, 1000);
</script>

</body>

</html>
