<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
    exit();
} else {
    if (isset($_POST['submit'])) {
        $eid = $_GET['editid'];

        // Retrieve form data
        $organization = $_POST['organization'];
        $name = $_POST['name'];
        $empid = $_POST['empid'];
        $emobilenumber = $_POST['emobilenumber'];
        $designation = $_POST['designation'];
        $educationalq = $_POST['educationalq'];
        $postingplace = $_POST['postingplace'];
        $typeofteam = $_POST['typeofteam'];
        $remark = $_POST['remark'];

        // Update the database record
        $query = mysqli_query($con, "UPDATE tblabroademp SET Organization='$organization', Name='$name', empid='$empid', emobilenumber='$emobilenumber', Designation='$designation', EducationalQ='$educationalq', postingplace='$postingplace', Typeofteam='$typeofteam', Remark='$remark' WHERE ID='$eid'");

        if ($query) {
            // Delete existing records for the entry ID
            mysqli_query($con, "DELETE FROM tbl_country_visits WHERE entry_id='$eid'");

            // Insert the new records for visited countries and time durations
            if (!empty($_POST['visited_countries']) && !empty($_POST['type_of_visit']) && !empty($_POST['go_no']) && !empty($_POST['total_date']) && !empty($_POST['visit_details'])) {
                $visited_countries = $_POST['visited_countries'];
                $type_of_visits = $_POST['type_of_visit'];
                $go_nos = $_POST['go_no'];
                $total_dates = $_POST['total_date'];
                $visit_details = $_POST['visit_details'];

                foreach ($visited_countries as $key => $country) {
                    $type_of_visit = $type_of_visits[$key];
                    $go_no = $go_nos[$key];
                    $total_date = $total_dates[$key];
                    $visit_detail = $visit_details[$key];

                    $start_date = date('Y-m-d', strtotime($_POST['start_date'][$key]));
                    $end_date = date('Y-m-d', strtotime($_POST['end_date'][$key]));

                    mysqli_query($con, "INSERT INTO tbl_country_visits (entry_id, visited_country, type_of_visit, go_no, total_date, visit_details, time_duration1, time_duration2) VALUES ('$eid', '$country', '$type_of_visit', '$go_no', '$total_date', '$visit_detail', '$start_date', '$end_date')");
                }
            }
            echo '<script>alert("Details have been updated successfully.")</script>';
        } else {
            echo '<script>alert("Something Went Wrong. Please try again.")</script>';
        }
    }
}

$eid = $_GET['editid'];
$query = "SELECT ae.ID, ae.empid, ae.EntryDate, ae.Organization, ae.Name, ae.emobilenumber, ae.Designation, ae.EducationalQ, ae.postingplace, ae.Typeofteam, ae.Remark, GROUP_CONCAT(DISTINCT cv.visited_country) as visited_countries, GROUP_CONCAT(CONCAT(DATE_FORMAT(cv.time_duration1, '%Y-%m-%d'), ' to ', DATE_FORMAT(cv.time_duration2, '%Y-%m-%d'))) as time_durations, GROUP_CONCAT(cv.type_of_visit) as type_of_visit, GROUP_CONCAT(cv.go_no) as go_no, GROUP_CONCAT(cv.total_date) as total_dates, GROUP_CONCAT(cv.visit_details) as visit_details
          FROM tblabroademp AS ae
          LEFT JOIN tbl_country_visits AS cv ON ae.ID = cv.entry_id
          WHERE ae.ID = '$eid'
          GROUP BY ae.ID";
$result = mysqli_query($con, $query);
$row = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title Page-->
    <title>Management System Details</title>
    <!-- Include CSS files -->
    <?php include_once('includes/css.php'); ?>
    <!-- Include jQuery UI CSS for datepicker -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <!-- Additional CSS styles -->
    <style>
        .card-body th,
        .card-body td {
            font-weight: bold;
            color: #000000;
            font-size: 20px;
        }

        .entry-details {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
        }

        .remove_country {
            color: red; /* Red color for remove button */
            cursor: pointer; /* Change cursor to pointer on hover */
            margin-top: 42px;
        }

        .space-before-start-date {
            margin-left: 6px !important; /* Space before start date field */
        }
    </style>
</head>
<body class="animsition">
<div class="page-wrapper">
    <!-- Include sidebar -->
    <?php include_once('includes/sidebar.php'); ?>
    <!-- PAGE CONTAINER-->
    <div class="page-container">
        <!-- Include header -->
        <?php include_once('includes/header.php'); ?>
        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div style="text-align: center; margin-bottom: 20px;">
                                    <img src="images/ec.jpg" alt="EC Image" style="max-width: 150px;">
                                </div>
                                <div class="card-header">
                                    <h3>Overseas Assignment Management System</h3>
                                </div>
                                <div class="card-body card-block">
                                    <form method="post">
                                        <table border="1" class="table table-bordered mg-b-0">
                                            <tr>
                                                <th>Entry Time in Software</th>
                                                <td><?php echo $row['EntryDate']; ?></td>
                                            </tr>
                                           <tr>
                                                <th>Name</th>
                                                <td><input type="text" name="name" value="<?php echo $row['Name']; ?>" required size="100"></td>
                                            </tr>
                                            <tr>
                                                <th>Employee ID</th>
                                                <td><input type="text" name="empid" value="<?php echo $row['empid']; ?>"
                                                           ></td>
                                            </tr>
                                            <tr>
                                                <th>Organization</th>
                                                <td>
                                                    <select name="organization" required>
                                                        <option value="">Select Organization</option>
                                                        <?php
                                                        $org_query = "SELECT DISTINCT Organization FROM tblabroademp";
                                                        $org_result = mysqli_query($con, $org_query);
                                                        while ($org_row = mysqli_fetch_assoc($org_result)) {
                                                            $selected = ($org_row['Organization'] == $row['Organization']) ? 'selected' : '';
                                                            echo "<option value='" . $org_row['Organization'] . "' $selected>" . $org_row['Organization'] . "</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Mobile Number</th>
                                                <td><input type="text" name="emobilenumber" value="<?php echo $row['emobilenumber']; ?>"></td>
                                            </tr>
                                            <tr>
                                                <th>Designation</th>
                                                <td><input type="text" name="designation" value="<?php echo $row['Designation']; ?>" required size="100"></td>
                                            </tr>
                                            <tr>
                                                <th>Educational Qualification</th>
                                                <td><input type="text" name="educationalq" value="<?php echo $row['EducationalQ']; ?>"></td>
                                            </tr>
                                           
                                            <tr>
                                                <th>Posting Place</th>
                                                <td><input type="text" name="postingplace" value="<?php echo $row['postingplace']; ?>" required size="100"></td>
                                            </tr>
                                            <tr>
                                                <th>Remark</th>
                                                <td><input type="text" name="remark" value="<?php echo $row['Remark']; ?>"></td>
                                            </tr>

                                            <tr>
                                                <th>Select Country</th>
                                                <td colspan="2">
                                                    <div id="visiting_countries">
                                                        <!-- Existing rows for visited countries will be added here -->
                                                        <?php
                                                        // Loop through stored visited countries and populate the fields
                                                        $visited_countries = explode(',', $row['visited_countries']);
                                                        $time_durations = explode(',', $row['time_durations']);
                                                        $type_of_visits = explode(',', $row['type_of_visit']);
                                                        $go_nos = explode(',', $row['go_no']);
                                                        $total_dates = explode(',', $row['total_dates']);
                                                        $visit_details = explode(',', $row['visit_details']);
                                                        foreach ($visited_countries as $key => $country) {
                                                            echo '<div class="row form-group">';
                                                            echo '<div class="col-12 col-md-0"></div>';
                                                            echo '<div class="col-12 col-md-3">';
                                                            echo '<label class="form-control-label">Visiting Country<span class="mandatory">*</span></label>';
                                                            echo '<input type="text" name="visited_countries[]" class="form-control" value="' . $country . '" required>';
                                                            echo '</div>';
                                                            echo '<div class="col-12 col-md-2">';
                                                            echo '<label class="form-control-label">Type of visit</label>';
                                                            echo '<input type="text" name="type_of_visit[]" class="form-control" value="' . $type_of_visits[$key] . '"  placeholder="Type of Visit">';
                                                            echo '</div>';
                                                            echo '<div class="col-12 col-md-2">';
                                                            echo '<label class="form-control-label">GO No</label>';
                                                            echo '<input type="text" name="go_no[]" class="form-control" value="' . $go_nos[$key] . '"  placeholder="GO No">';
                                                            echo '</div>';
                                                            echo '<div class="col-12 col-md-2">';
                                                            echo '<label class="form-control-label">Total Days</label>';
                                                            echo '<input type="text" name="total_date[]" class="form-control" value="' . $total_dates[$key] . '"  placeholder="Total Date">';
                                                            echo '</div>';
                                                            echo '<div class="col-12 col-md-3">';
                                                            echo '<label class="form-control-label">Visit Remarks</label>';
                                                            echo '<input type="text" name="visit_details[]" class="form-control" value="' . $visit_details[$key] . '"  placeholder="Visit Details/Remarks">';
                                                            echo '</div>';
                                                            
                                                            // Start Date and End Date fields
                                                            echo '<div class="row form-group space-before-start-date">';
                                                            echo '<div class="col-12 col-md-6">';
                                                            echo '<label class="form-control-label">Start Date<span class="mandatory">*</span></label>';
                                                            echo '<input type="date" name="start_date[]" class="form-control start_date" value="' . date('Y-m-d', strtotime(explode(' to ', $time_durations[$key])[0])) . '" required>';
                                                            echo '</div>';
                                                            echo '<div class="col-12 col-md-6">';
                                                            echo '<label class="form-control-label">End Date<span class="mandatory">*</span></label>';
                                                            echo '<input type="date" name="end_date[]" class="form-control end_date" value="' . date('Y-m-d', strtotime(explode(' to ', $time_durations[$key])[1])) . '" required>';
                                                            echo '</div>';
                                                            echo '</div>';
                                                            
                                                            echo '<div class="col-12 col-md">';
                                                            echo '<button type="button" class="btn btn-sm btn-danger remove_country"><i class="fa fa-times-circle"></i></button>';
                                                            echo '</div>';
                                                            echo '</div>';
                                                        }
                                                        ?>
                                                    </div>
                                                    <button type="button" class="add_country btn btn-primary">Add More</button>
                                                </td>
                                            </tr>
                                            <!-- Submit and Go Back buttons -->
                                            <tr>
                                                <td colspan="2" style="text-align: center;">
                                                    <button type="submit" name="submit" class="btn btn-primary">Update</button>
                                                    <button type="button" onclick="goBack();" class="btn btn-secondary">Go Back</button>
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Include footer -->
        <?php include_once('includes/footer.php'); ?>
    </div>
        <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="js/main.js"></script>
</div>
<!-- Include JS files -->
<?php include_once('includes/js.php'); ?>
<!-- Include jQuery and jQuery UI for datepicker -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script>
    // JavaScript code for adding and removing visiting country fields
    $(document).ready(function () {
        $(".add_country").click(function () {
            // Add new visiting country fields
            var html = `
                <div class="row form-group">
                    <div class="col-12 col-md-0"></div>
                    <div class="col-12 col-md-3">
                        <label class="form-control-label">Visiting Country<span class="mandatory">*</span></label>
                        <input type="text" name="visited_countries[]" class="form-control" required>
                    </div>
                    <div class="col-12 col-md-2">
                        <label class="form-control-label">Type of visit</label>
                        <input type="text" name="type_of_visit[]" class="form-control"  placeholder="Type of Visit">
                    </div>
                    <div class="col-12 col-md-2">
                        <label class="form-control-label">GO No</label>
                        <input type="text" name="go_no[]" class="form-control"  placeholder="GO No">
                    </div>
                    <div class="col-12 col-md-2">
                        <label class="form-control-label">Total Days</label>
                        <input type="text" name="total_date[]" class="form-control"  placeholder="Total Date">
                    </div>
                    <div class="col-12 col-md-3">
                        <label class="form-control-label">Visit Remarks</label>
                        <input type="text" name="visit_details[]" class="form-control"  placeholder="Visit Details/Remarks">
                    </div>
                    <div class="row form-group space-before-start-date">

    <div class="col-12 col-md-6">
        <label class="form-control-label">&nbsp;Start Date<span class="mandatory">*</span></label>
        <input type="date" name="start_date[]" class="form-control start_date" required>
    </div>
    <div class="col-12 col-md-6">
        <label class="form-control-label">End Date<span class="mandatory">*</span></label>
        <input type="date" name="end_date[]" class="form-control end_date" required>
    </div>
</div>

                    <div class="col-12 col-md">
                        <button type="button" class="btn btn-sm btn-danger remove_country"><i class="fa fa-times-circle"></i></button>
                    </div>
                </div>`;
            $("#visiting_countries").append(html);
            // Initialize datepicker for the newly added start date and end date fields
            $(".start_date, .end_date").datepicker({dateFormat: 'yy-mm-dd'});
        });

        // Remove visiting country fields
        $("#visiting_countries").on('click', '.remove_country', function () {
            $(this).closest('.row').remove(); // Remove the entire row for the visiting country
        });
    });
</script>
 <!-- JavaScript function for "Go Back" button -->
    <script>
        function goBack() {
            window.history.back();
            window.history.replaceState(null, document.title, window.location.href);
        }
    </script>
</body>
</html>
