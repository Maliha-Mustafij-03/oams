<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['atsmsaid']) == 0) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $eid = $_GET['editid'];
        
        // Retrieve form data
        $organization = $_POST['organization'];
        $name = $_POST['name'];
        $empid = $_POST['empid'];
        $emobilenumber = $_POST['emobilenumber'];
        $designation = $_POST['designation'];
        $educationalq = $_POST['educationalq'];
        $postingplace = $_POST['postingplace'];
        $typeofteam = $_POST['typeofteam'];
        $remark = $_POST['remark'];
        $visited_countries = $_POST['visited_countries'];
        $time_durations = $_POST['time_durations'];

        // Update the database record
        $query = mysqli_query($con, "UPDATE tblabroademp SET Organization='$organization', Name='$name', empid='$empid', emobilenumber='$emobilenumber', Designation='$designation', EducationalQ='$educationalq', postingplace='$postingplace', Typeofteam='$typeofteam', Remark='$remark' WHERE ID='$eid'");

        if ($query) {
            // Update the visited countries and time durations in tbl_country_visits table
            // First, delete existing records for the entry ID
            mysqli_query($con, "DELETE FROM tbl_country_visits WHERE entry_id='$eid'");
            // Then, insert the new records
            if (!empty($visited_countries) && !empty($time_durations)) {
                $countries = explode(",", $visited_countries);
                $durations = explode(",", $time_durations);
                foreach ($countries as $key => $country) {
                    $duration = explode(" to ", $durations[$key]);
                    $start_date = date('Y-m-d', strtotime($duration[0]));
                    $end_date = date('Y-m-d', strtotime($duration[1]));
                    mysqli_query($con, "INSERT INTO tbl_country_visits (entry_id, visited_country, time_duration1, time_duration2) VALUES ('$eid', '$country', '$start_date', '$end_date')");
                }
            }
            echo '<script>alert("Details have been updated successfully.")</script>';
        } else {
            echo '<script>alert("Something Went Wrong. Please try again.")</script>';
        }
    }

    $eid = $_GET['editid'];
    $query = "SELECT ae.empid, ae.EntryDate, ae.Organization, ae.Name, ae.emobilenumber, ae.Designation, ae.EducationalQ, ae.postingplace, ae.Typeofteam, ae.Remark, GROUP_CONCAT(cv.visited_country) as visited_countries, GROUP_CONCAT(CONCAT(DATE_FORMAT(cv.time_duration1, '%d-%m-%Y'), ' to ', DATE_FORMAT(cv.time_duration2, '%d-%m-%Y'))) as time_durations
              FROM tblabroademp AS ae
              LEFT JOIN tbl_country_visits AS cv ON ae.ID = cv.entry_id
              WHERE ae.ID = '$eid'
              GROUP BY ae.ID";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Title Page-->
    <title>Management System Details</title>
    <!-- Include CSS files -->
    <?php include_once('includes/css.php');?>
</head>
<body class="animsition">
    <div class="page-wrapper">
        <!-- Include sidebar -->
        <?php include_once('includes/sidebar.php');?>
        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- Include header -->
            <?php include_once('includes/header.php');?>
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Employee Entry Details</strong>
                                    </div>

                                    <div class="card-body card-block">
                                        <form method="post">
                                            <table border="1" class="table table-bordered mg-b-0">
                                                <tr>
                                                    <th>Employee ID</th>
                                                    <td><?php echo $row['empid'];?></td>
                                                </tr>
                                                <tr>
                                                    <th>Entry Time in Software</th>
                                                    <td><?php echo $row['EntryDate'];?></td>
                                                </tr>
                                                <tr>
                                                    <th>Organization</th>
                                                    <td><input type="text" name="organization" value="<?php echo $row['Organization'];?>" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Name</th>
                                                    <td><input type="text" name="name" value="<?php echo $row['Name'];?>" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Mobile Number</th>
                                                    <td><input type="text" name="emobilenumber" value="<?php echo $row['emobilenumber'];?>" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Designation</th>
                                                    <td><input type="text" name="designation" value="<?php echo $row['Designation'];?>" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Educational Qualification</th>
                                                    <td><input type="text" name="educationalq" value="<?php echo $row['EducationalQ'];?>" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Posting Place</th>
                                                    <td><input type="text" name="postingplace" value="<?php echo $row['postingplace'];?>" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Type of Team</th>
                                                    <td><input type="text" name="typeofteam" value="<?php echo $row['Typeofteam'];?>" required></td>
                                                </tr>
                                                <tr>
                                                    <th>Visited Countries</th>
                                                    <td><input type="text" name="visited_countries" value="<?php echo $row['visited_countries'];?>"></td>
                                                </tr>
                                                <tr>
                                                    <th>Time Durations</th>
                                                    <td><input type="text" name="time_durations" value="<?php echo $row['time_durations'];?>"></td>
                                                </tr>
                                                <tr>
                                                    <th>Remark</th>
                                                    <td><input type="text" name="remark" value="<?php echo $row['Remark'];?>"></td>
                                                </tr>
                                            </table>
                                            <button type="submit" name="submit" class="btn btn-primary">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Include footer -->
            <?php include_once('includes/footer.php');?>
        </div>
    </div>
    <!-- Include JS files -->
    <?php include_once('includes/js.php');?>
</body>
</html>
<?php }  ?>
