<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management System || Dashboard</title>
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/theme.css" rel="stylesheet">
    <!-- Sidebar CSS -->
    <style>
        /* Sidebar Styles */
        .menu-sidebar {
            background-color: #0f4233 !important; /*  background color */
            color: #fff; /* Text color */
            width: 350px; /* Increase sidebar width */
            height: 100vh; /* Set sidebar height to full viewport height */
            position: fixed; /* Fix sidebar position */
            top: 0; /* Align sidebar to the top of the viewport */
            left: 0; /* Align sidebar to the left of the viewport */
            overflow-y: auto; /* Enable vertical scrolling if content exceeds viewport height */
            z-index: 1000; /* Set higher z-index to ensure sidebar overlays other content */
            white-space: nowrap; /* Prevent line breaks */
        }

        .menu-sidebar .logo {
            padding: 20px;
            text-align: center;
            border-bottom: 2px solid #fff; /* Border color */
            transition: all 0.3s; /* Smooth transition for logo */
        }

        .menu-sidebar .logo h6 {
            margin: 0;
            font-size: 20px; /* Increase font size */
            transition: all 0.3s; /* Smooth transition for logo */
        }

        .menu-sidebar__content {
            padding: 0.1px;
        }

        .navbar-sidebar {
            margin-top: 30px;
        }

        .navbar-sidebar ul {
            padding: 0;
            margin: 0; /* Remove default margin */
        }

        .navbar-sidebar li {
            list-style: none;
        }

        .navbar-sidebar a {
            color: #ffff66 !important; /* Text color */
            display: block;
            padding: 15px 20px; /* Adjust padding */
            text-decoration: none;
            transition: background-color 0.3s, color 0.3s; /* Add color transition */
            font-size: 18px !important; /* Increase font size */
            position: relative; /* Relative positioning for animations */
            font-weight: bold !important; /* Make text bold */
            display: flex;
            align-items: center; /* Align vertically */
        }

        .navbar-sidebar a:hover {
            background-color: #87CEEB !important; /* Hover background color */
            color: #000080 !important; /* Change text color on hover */
        }

        .navbar-sidebar a::before {
            content: "";
            position: absolute;
            top: 50%;
            left: -30px;
            transform: translateY(-50%);
            width: 30px;
            height: 30px;
            background-color: #007bff;
            border-radius: 50%;
            transition: all 0.3s;
            opacity: 0;
        }

        .navbar-sidebar a:hover::before {
            left: 0;
            opacity: 1;
        }

        .navbar__sub-list {
            padding-left: 20px;
            display: none;
        }

        .has-sub > a::after {
            content: '\f078';
            font-family: 'Font Awesome 5 Free';
            font-size: 20px; /* Increase icon size */
            float: right;
        }

        .has-sub.active > a::after {
            content: '\f077';
        }

        .navbar__sub-list a {
            color: #ccc; /* Sub-menu text color */
            padding: 8px 0;
            display: block;
            transition: color 0.3s;
        }

        .navbar__sub-list a:hover {
            color: #fff; /* Hover text color */
        }

        .navbar-sidebar a i {
            margin-right: 10px; /* Adjust icon spacing */
        }

        .navbar-sidebar a span {
            white-space: nowrap; /* Prevent text from wrapping */
        }

        /* Allow wrapping for IDEA Project(Phase-2) */
        .navbar-sidebar .project-phase-2 {
            white-space: normal;
        }
    </style>
</head>

<body>
    <div class="page-wrapper">
        <!-- HEADER -->
        <?php include_once('includes/header.php');?>
        <!-- END HEADER -->

        <aside class="menu-sidebar d-none d-lg-block">
    <div class="logo" style="background-color: #0f4233;">
    <marquee behavior="scroll" direction="up" scrollamount="2" style="color: yellow !important;">
         <h6 style="color: yellow;">Overseas Assignment Management System</h6>
    </marquee>
</div>

    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a href="dashboard.php">
                        <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                </li>
                <li>
                    <a href="new-entry-form.php">
                        <i class="fas fa-user"></i>New Entry</a>
                </li>
                <!-- <li>
                 <li>
                    <a href="manage-all-entry.php">
                        <i class="fas fa-user"></i>All Details</a>
                </li>
                <li>
                    <a href="bec-entry.php">
                        <i class="fas fa-user"></i>BEC Details</a>
                </li>
                <li>
                    <a href="ict_wing.php">
                        <i class="fas fa-user"></i>ICT Wing Details</a>
                </li>
                <li>
                    <a href="manage-nid-entry.php">
                        <i class="fas fa-user"></i>NID Wing Details</a>
                </li>
                <li>
                            <a href="manage idea_2.php">
                                <i class="fas fa-user"></i>
                                <span class="project-phase-2">IDEA Project(Phase-2) Details</span>
                            </a>
                        </li>
   
</li> -->


                 <li class="has-sub">
                    <a class="js-arrow" href="#">
                        <i class="fas fa-user"></i>Details</a>
                    <ul class="list-unstyled navbar__sub-list js-sub-list">
                        <li><a href="manage-all-entry.php">All</a></li>
                        <li><a href="bec-entry.php">BEC</a></li>
                        <li><a href="ecs-entry.php">ECS</a></li>
                        <li><a href="ict_wing.php">ICT Wing</a></li>
                        <li><a href="manage-nid-entry.php">NID WING</a></li>
                        <li><a href="manage idea_2.php">IDEA Project(Ph-2)</a></li>
                        
                    </ul>
                
                <li>
                    <a href="report.php">
                        <i class="fas fa-copy"></i>Search Report</a>
                </li>
                <li>
                    <a href="logout.php">
                        <i class="fas fa-tachometer-alt"></i> log out</a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
