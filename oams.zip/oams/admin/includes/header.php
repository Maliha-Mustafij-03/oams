<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management System || Dashboard</title>
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/theme.css" rel="stylesheet">
    <!-- Header CSS -->
    <style>
        /* Header Styles */
        .header-desktop {
            background-color: #0b6623; /* Green background color */
            color: #fff; /* Text color */
            padding: 10px; /* Reduce padding */
        }

        .header-desktop .header-wrap {
            padding: 10px;
        }

        .form-header {
            display: inline-block;
        }

        .form-header input[type="text"] {
            border: 1px solid #fff; /* White border color */
            background-color: transparent;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            width: 300px;
            margin-right: 10px;
            transition: border-color 0.3s;
            font-size: 30px !important; /* Font size set to 30px */
        }

        .form-header input[type="text"]:focus {
            border-color: #485460; /* Focus border color */
        }

        .au-btn--submit {
            border: none;
            background-color: transparent;
            color: #fff;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            font-size: 30px !important; /* Font size set to 30px */
        }

        .au-btn--submit:hover {
            background-color: #485460; /* Hover background color */
        }

        .account-wrap {
            float: right;
        }

        .account-item {
            display: inline-block;
            margin-left: 20px;
            position: relative;
        }

        .account-item .image img {
            width: 30px !important; /* Reduce avatar image size */
            border-radius: 50%;
        }

        .account-dropdown {
            position: absolute;
            top: calc(100% - 5px); /* Adjust dropdown position */
            right: 0;
            background-color: #485460; /* Dropdown background color */
            color: #fff; /* Dropdown text color */
            border-radius: 5px;
            display: none;
            padding: 10px;
            z-index: 1;
        }

        .account-item:hover .account-dropdown {
            display: block;
        }

        .account-dropdown__body {
            padding: 10px 0;
        }

        .account-dropdown__item a {
            color: #fff; /* Dropdown link text color */
            display: block;
            padding: 5px 0;
            transition: color 0.3s;
        }

        .account-dropdown__item a:hover {
            color: #ccc; /* Dropdown link hover color */
        }

        .account-dropdown__footer a {
            color: #fff; /* Logout link text color */
            display: block;
            padding: 5px 0;
            transition: color 0.3s;
        }

        .account-dropdown__footer a:hover {
            color: #ccc; /* Logout link hover color */
        }
        /* Additional CSS for Search Placeholder */
        ::placeholder {
            color: #fff !important; /* White color */
            font-weight: bold !important; /* Bold font weight */
            font-size: 30px !important; /* 30px font size */
            opacity: 1; /* Ensure full opacity */
        }
        @media print {
            .au-input,
            .account-item .image img,
            .au-btn--submit,
            .header-desktop {
                display: none;
            }
        }
        /* Style the placeholder text color */
    input.form-control::placeholder {
        color: lightgreen !important; /* Change placeholder text color to light green */
        font-size: 16px !important; /* Set the font size of the placeholder text */
        font-weight: normal; /* Set the font weight of the placeholder text */
    }

    </style>
</head>

<body>
    <header class="header-desktop">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="header-wrap">
                    <form class="form-header" name="search" action="search-all.php" method="post">
                        <input class="au-input au-input--xl" type="text" name="searchdata" id="searchdata" placeholder="Search...." />
                       <button class="au-btn--submit" type="submit" name="search" style="padding: 15px !important;">
    <span style="font-size: 40px !important;"><i class="zmdi zmdi-search"></i></span>
</button>



                    </form>
                    <div class="account-wrap">
                        <div class="account-item clearfix js-item-menu">
                            <div class="image">
                                <a href="logout.php">
                                    <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                </a>
                            </div>
                            <div class="content">
                                <a class="js-acc-btn" href="admin-profile.php"><?php echo $name; ?></a>
                            </div>
                            <div class="account-dropdown js-dropdown">
                                <div class="info clearfix">
                                    <div class="image">
                                        <a href="#">
                                            <img src="images/icon/avatar-01.jpg" alt="IDEA-2" />
                                        </a>
                                    </div>
                                    <div class="content">
                                        <h5 class="name">
                                            <a href="#"><?php echo $name; ?></a>
                                        </h5>
                                    </div>
                                </div>
                                <div class="account-dropdown__body">
                                    <div class="account-dropdown__item">
                                        <a href="admin-profile.php">
                                            <i class="zmdi zmdi-account"></i>Profile</a>
                                    </div>
                                    <div class="account-dropdown__item">
                                        <a href="change-password.php">
                                            <i class="zmdi zmdi-settings"></i>Change Password</a>
                                    </div>
                                </div>
                                <div class="account-dropdown__footer">
                                    <a href="logout.php">
                                        <i class="zmdi zmdi-power"></i>Logout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
</body>

</html>
