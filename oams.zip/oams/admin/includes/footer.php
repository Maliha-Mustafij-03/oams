<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p style="color: darkred;">Overseas Assignment Management System.Copyright by IDEA Project (Phase-2)</p>
                                </div>
                            </div>
                        </div>