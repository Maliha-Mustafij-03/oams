<?php
session_start();
error_reporting(0);
include('admin/includes/dbconnection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Data</title>
    <!-- Include CSS styles -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="admin/assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="admin/assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background-color: #28a745;
            color: #fff;
            text-align: center;
            padding: 10px;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .footer {
            background-color: #ffc107;
            color: #333;
            text-align: center;
            padding: 10px;
            font-size: 18px;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th,
        td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        th {
            background-color: #28a745;
            color: #fff;
            text-align: left;
        }
        td {
            background-color: #f8f9fa; /* Change to ash color */
            color: #555; /* Change to ash color */
        }
        .print-icon {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">Print Data</div>
        <?php
        $cid = $_GET['vid'];
        $ret = mysqli_query($con, "select * from tblabroademp where ID='$cid'");
        $cnt = 1;
        while ($row = mysqli_fetch_array($ret)) {
        ?>
            <table>
                <tr>
                    <th colspan="4">Details</th>
                </tr>
                <tr>
                    <th>ID Number</th>
                    <td><?php echo $row['empid']; ?></td>
                    <th>Organization</th>
                    <td><?php echo $row['Organization']; ?></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><?php echo $row['Name']; ?></td>
                    <th>Posting Place</th>
                    <td><?php echo $row['postingplace']; ?></td>
                </tr>
                <tr>
                    <th>Mobile Number</th>
                    <td><?php echo $row['emobilenumber']; ?></td>
                    <th>Designation</th>
                    <td><?php echo $row['Designation']; ?></td>
                </tr>
                <tr>
                    <th>Entry Time in Software</th>
                    <td><?php echo $row['EntryDate']; ?></td>
                    <th>Visited Country</th>
                    <td><?php echo $row['Status']; ?></td>
                </tr>
                <tr>
                    <th>Time Duration</th>
                    <td colspan="3"><?php echo $row['Price']; ?></td>
                </tr>
                <?php if ($row['Remark'] != "") { ?>
                    <tr>
                        <th>Remark</th>
                        <td colspan="3"><?php echo $row['Remark']; ?></td>
                    </tr>
                <?php } ?>
                <tr>
                    <td colspan="4" style="text-align: center;">
                        <button class="fa fa-print fa-2x print-icon" onclick="window.print()"></button>
                    </td>
                </tr>
            </table>
        <?php } ?>
        <div class="footer">Thank you for using our service.</div>
    </div>
</body>
</html>
