<?php
session_start();
error_reporting(0);
include('admin/includes/dbconnection.php');

if (isset($_POST['search'])) {
    $sdata = $_POST['searchdata'];
    $team = $_POST['team']; // Added code to get the selected team
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Management System || Search</title>
    <!-- Fontfaces CSS-->
    <link href="admin/css/font-face.css" rel="stylesheet" media="all">
    <!-- Other CSS imports -->
</head>

<body class="animsition">
    <div class="page-wrapper">
        <h3 align="center" style="margin-top:1%">Management System</h3>
        <hr />
        <div class="main-content" style="margin-top:-4%">
            <div>
                <div>
                    <div class="row" align="center">
                        <div align="center" style="margin-left:20%">
                            <form class="form-header" name="search" method="post">
                                <input class="au-input au-input--xl" type="text" name="searchdata" id="searchdata" placeholder="Search by names &amp; Visited Country..." required />
                                <button class="au-btn--submit" type="submit" name="search">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                        </div>
                        <div class="col-lg-12">
                            <div class="table-responsive table--no-card m-b-30">
                                <h4 align="center">Result against "<?php echo $sdata; ?>" keyword </h4>
                                <hr />
                                <!-- Print Button -->
                                <div style="margin-bottom: 20px;">
                                    <button onclick="window.print()" class="btn btn-primary">Print</button>
                                </div>
                                <!-- End Print Button -->
                                <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                        <tr>
                                            <th>S.NO</th>
                                            <th>id Number</th>
                                            <th>Organization</th>
                                            <th>Name</th>
                                            <th>Entry Date</th>
                                            <th>Designation</th>
                                            <th>Posting Place</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "SELECT e.ID, e.empid, e.Organization, e.Name, e.EntryDate, e.Designation, e.postingplace
                                                    FROM tblabroademp e 
                                                    LEFT JOIN tbl_country_visits cv ON e.ID = cv.entry_id
                                                    WHERE (e.Name LIKE '%$sdata%' OR cv.visited_country LIKE '%$sdata%' OR e.Designation LIKE '%$sdata%' OR e.Organization LIKE '%$sdata%')
                                                    AND (e.Typeofteam = '$team' OR '$team' = '')"; // Updated SQL query
                                        $result = mysqli_query($con, $query);
                                        if (mysqli_num_rows($result) > 0) {
                                            $cnt = 1;
                                            while ($row = mysqli_fetch_assoc($result)) {
                                        ?>
                                                <tr>
                                                    <td><?php echo $cnt; ?></td>
                                                    <td><?php echo $row['empid']; ?></td>
                                                    <td><?php echo $row['Organization']; ?></td>
                                                    <td><?php echo $row['Name']; ?></td>
                                                    <td><?php echo $row['EntryDate']; ?></td>
                                                    <td><?php echo $row['Designation']; ?></td>
                                                    <td><?php echo $row['postingplace']; ?></td>
                                                    <td>
                                                        <a href="all-entry-detail.php?editid=<?php echo $row['ID']; ?>" title="View Full Details" class="btn btn-success">Detail</a>
                                                        <a href="auto-edit-detail.php?editid=<?php echo $row['ID']; ?>" title="View Edit" class="btn btn-danger">Edit</a>
                                                        <a href="print.php?vid=<?php echo $row['ID']; ?>" style="cursor:pointer" target="_blank" class="btn btn-warning">Print</a>
                                                        <a href="manage-all-entry.php?del=<?php echo $row['ID']; ?>" onclick="return confirm('Do you really want to delete the entry?');" class="btn btn-success">Delete</a>
                                                    </td>
                                                </tr>
                                        <?php
                                                $cnt = $cnt + 1;
                                            }
                                        } else {
                                        ?>
                                            <tr>
                                                <td colspan="8"> No record found against this search</td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once('includes/footer.php'); ?>
    <!-- JS imports -->
</body>

</html>
<?php } ?>
